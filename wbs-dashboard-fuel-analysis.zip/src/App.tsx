import React, { useState, useMemo, useRef, useEffect } from "react";
import { 
  Fuel, 
  Calendar, 
  TrendingUp, 
  Filter, 
  PlusCircle, 
  Database, 
  AlertTriangle, 
  Info, 
  FileSpreadsheet, 
  Sparkles,
  ChevronDown,
  User,
  Clock,
  Upload,
  Download,
  RotateCcw,
  ArrowRight,
  ArrowLeft,
  Link as LinkIcon,
  LogOut,
  Globe,
  RefreshCw,
  FileText,
  Check,
  SlidersHorizontal,
  Cloud,
  CloudOff,
  CalendarDays
} from "lucide-react";
import * as XLSX from "xlsx";
import html2canvas from "html2canvas-pro";
import { jsPDF } from "jspdf";
import { FuelRecord, EgyPlanMap, UnitRegistryMap } from "./types";
import { INITIAL_FUEL_DATA, processRecord, parsePastedData, normalizeDateToYMD, formatExcelTime, deriveEgy, cleanEgyName, deriveEquipmentType, mergeWithYearlyRecords, getCanonicalUnitId } from "./data/sampleData";
import MetricCard from "./components/MetricCard";
import ParetoChart from "./components/ParetoChart";
import AnomalyDetailsView from "./components/AnomalyDetailsView";
import YearlyReview from "./components/YearlyReview";
import EgyPlanManagerModal from "./components/EgyPlanManagerModal";
import PlanVsActualAssessment from "./components/PlanVsActualAssessment";
import PlanFuelBurnPage from "./components/PlanFuelBurnPage";
import DailyReviewView from "./components/DailyReviewView";
import UnitSelectorDropdown, { UnitItem } from "./components/UnitSelectorDropdown";
import { 
  getStoredEgyPlans, 
  saveStoredEgyPlans, 
  subscribeToEgyPlans, 
  getStoredUnitRegistry,
  saveStoredUnitRegistry,
  saveUnitRegistryToFirestore,
  subscribeToUnitRegistry,
  resolvePlanForUnit, 
  DEFAULT_EGY_PLANS 
} from "./lib/egyPlanService";
import { 
  saveMonthlyReportToFirestore, 
  saveActiveDatasetToFirestore, 
  fetchActiveDatasetFromFirestore, 
  subscribeToActiveDataset, 
  subscribeToMonthlyReports,
  deleteActiveDatasetFromFirestore 
} from "./lib/firebase";
import { saveLocalData, getLocalData, getSyncLocalData, clearAllLocalData } from "./lib/storage";
import { MonthlyReportData } from "./types";
import { 
  initAuth, 
  googleSignIn, 
  logout, 
  extractSpreadsheetId, 
  fetchSpreadsheetMetadata, 
  fetchSheetValues 
} from "./lib/googleSheets";

const INITIAL_PLANS: Record<string, { idAlat: string; egy: string; typeAlat: string; planFuelBurn: number }> = {
  "DT23001": { idAlat: "DT23001", egy: "DUMP TRUCK", typeAlat: "HINO 500 (FM260JD)", planFuelBurn: 7.5 },
  "DT23005": { idAlat: "DT23005", egy: "DUMP TRUCK", typeAlat: "HINO 500 (FM280JD)", planFuelBurn: 6.5 },
  "EX23001": { idAlat: "EX23001", egy: "EXCAVATOR", typeAlat: "KOMATSU PC 210", planFuelBurn: 13.0 },
  "EX23203": { idAlat: "EX23203", egy: "EXCAVATOR", typeAlat: "CAT 320 GC", planFuelBurn: 16.0 },
  "DZ23001": { idAlat: "DZ23001", egy: "BULLDOZER", typeAlat: "CATERPILAR D8T", planFuelBurn: 28.0 },
  "TL23002": { idAlat: "TL23002", egy: "TOWER LAMP", typeAlat: "TOWER LAMP", planFuelBurn: 3.0 },
  "LV23207": { idAlat: "LV23207", egy: "LIGHT VEHICLE", typeAlat: "TOYOTA INNOVA", planFuelBurn: 4.0 },
  "CT23001": { idAlat: "CT23001", egy: "CRANE TRUCK", typeAlat: "HINO 500 (FM280JD)", planFuelBurn: 6.5 },
  "FT23001": { idAlat: "FT23001", egy: "FUEL TRUCK", typeAlat: "DUTRO 136 HD", planFuelBurn: 7.0 },
  "FL23001": { idAlat: "FL23001", egy: "FORKLIFT", typeAlat: "KOMATSU FD150E - 8", planFuelBurn: 6.0 },
  "WT23102": { idAlat: "WT23102", egy: "WATER TRUCK", typeAlat: "DUTRO 136 HD", planFuelBurn: 6.0 },
  "WT23001": { idAlat: "WT23001", egy: "WATER TRUCK", typeAlat: "HINO 500 (FM260JD)", planFuelBurn: 6.0 },
  "WT23002": { idAlat: "WT23002", egy: "WATER TRUCK", typeAlat: "HINO 500 (FM280JD)", planFuelBurn: 6.0 },
  "WT23003": { idAlat: "WT23003", egy: "WATER TRUCK", typeAlat: "HINO 500 (FM260JD)", planFuelBurn: 6.0 },
  "RS23003": { idAlat: "RS23003", egy: "REACH STACKER", typeAlat: "KONECRANE 45T", planFuelBurn: 12.5 },
  "FD23001": { idAlat: "FD23001", egy: "FLAT DECK", typeAlat: "HINO 500 (FM260JD)", planFuelBurn: 7.0 },
  "FD23209": { idAlat: "FD23209", egy: "FLAT DECK", typeAlat: "HINO 500 (FM260JD)", planFuelBurn: 7.0 },
  "EXC-PC200-01": { idAlat: "EXC-PC200-01", egy: "EXCAVATOR", typeAlat: "KOMATSU PC 210", planFuelBurn: 13.0 },
  "DT-HD785-05": { idAlat: "DT-HD785-05", egy: "DUMP TRUCK", typeAlat: "HINO 500 (FM280JD)", planFuelBurn: 6.5 },
  "BULL-D85-01": { idAlat: "BULL-D85-01", egy: "BULLDOZER", typeAlat: "KOMATSU D85SS", planFuelBurn: 25.0 },
  "GRAD-GD511-01": { idAlat: "GRAD-GD511-01", egy: "MOTOR GRADER", typeAlat: "KOMATSU GD 535", planFuelBurn: 10.0 },
  "LOAD-WA500-02": { idAlat: "LOAD-WA500-02", egy: "WHEEL LOADER", typeAlat: "KOMATSU WA 500", planFuelBurn: 30.0 },
};

export default function App() {
  // Core fuel dataset state (initialized immediately from localStorage with INITIAL_FUEL_DATA fallback)
  const [records, setRecords] = useState<FuelRecord[]>(() => {
    const local = getSyncLocalData<FuelRecord[]>("fuel_records", []);
    const source = local && local.length > 0 ? mergeWithYearlyRecords(local) : INITIAL_FUEL_DATA;
    return source.map(r => {
      const canonId = getCanonicalUnitId(r.idAlat);
      if (canonId && canonId !== r.idAlat) {
        return { ...r, idAlat: canonId };
      }
      return r;
    });
  });

  // Plans from "List & FC" sheet (Column A: nomor unit, Column B: type alat, Column C: egy alat, Column D: plan Fuel Burn)
  const [plans, setPlans] = useState<Record<string, { idAlat: string; egy?: string; typeAlat: string; planFuelBurn: number }>>(() => {
    const rawPlans = getSyncLocalData<Record<string, { idAlat: string; egy?: string; typeAlat: string; planFuelBurn: number }>>("fuel_plans", INITIAL_PLANS);
    const cleaned: Record<string, { idAlat: string; egy?: string; typeAlat: string; planFuelBurn: number }> = {};
    Object.entries(rawPlans).forEach(([k, v]) => {
      const canonId = getCanonicalUnitId(k).toUpperCase();
      cleaned[canonId] = {
        ...v,
        idAlat: canonId
      };
    });
    return cleaned;
  });

  // Dynamic benchmark plans by Jenis Egy (EgyPlanMap)
  const [egyPlans, setEgyPlans] = useState<EgyPlanMap>(() => {
    return getStoredEgyPlans();
  });
  const [isEgyPlanModalOpen, setIsEgyPlanModalOpen] = useState<boolean>(false);

  // Registered operational unit fleet & custom unit-level plans
  const [unitRegistry, setUnitRegistry] = useState<UnitRegistryMap>(() => {
    return getStoredUnitRegistry();
  });

  // Subscribe to real-time updates for egyPlans from Firestore
  useEffect(() => {
    const unsub = subscribeToEgyPlans((latest) => {
      setEgyPlans(latest);
    });
    return () => unsub();
  }, []);

  // Subscribe to real-time updates for unitRegistry from Firestore
  useEffect(() => {
    const unsub = subscribeToUnitRegistry((latest) => {
      setUnitRegistry(latest);
    });
    return () => unsub();
  }, []);

  const handleSaveEgyPlans = async (updated: EgyPlanMap) => {
    setEgyPlans(updated);
    await saveStoredEgyPlans(updated);
    setFileFeedback({
      type: "success",
      message: "Target Plan Fuel Burn per Jenis Egy berhasil diperbarui dan disinkronkan ke cloud!"
    });
  };

  const handleSaveUnitRegistry = async (updated: UnitRegistryMap) => {
    setUnitRegistry(updated);
    saveStoredUnitRegistry(updated);
    try {
      await saveUnitRegistryToFirestore(updated);
    } catch (e) {
      console.warn("Could not save unit registry to firestore:", e);
    }
  };

  // Available unique Egy categories across the current dataset
  const availableEgys = useMemo(() => {
    const egys = new Set<string>();
    records.forEach(r => {
      const egy = r.egy || deriveEgy(r.idAlat, r.typeAlat);
      if (egy) egys.add(egy);
    });
    return Array.from(egys).sort();
  }, [records]);

  // States for processing Excel/CSV files directly
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [fileFeedback, setFileFeedback] = useState<{ type: "success" | "error" | null; message: string }>({ type: null, message: "" });
  const [isDragging, setIsDragging] = useState(false);

  // Dynamic user-triggered file stages before analysis
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileSheets, setFileSheets] = useState<string[]>([]);
  const [selectedLogSheet, setSelectedLogSheet] = useState<string>("");
  const [hasPlanSheetPresent, setHasPlanSheetPresent] = useState<boolean>(false);

  // Filter States with initial storage restoration
  const [startDate, setStartDate] = useState<string>(() => {
    const meta = getSyncLocalData<{ startDate?: string; endDate?: string }>("fuel_meta", { startDate: "2026-04-01", endDate: "2026-04-30" });
    return meta?.startDate || "2026-04-01";
  });
  const [endDate, setEndDate] = useState<string>(() => {
    const meta = getSyncLocalData<{ startDate?: string; endDate?: string }>("fuel_meta", { startDate: "2026-04-01", endDate: "2026-04-30" });
    return meta?.endDate || "2026-04-30";
  });
  const [selectedEgyFilter, setSelectedEgyFilter] = useState("SEMUA");
  const [selectedStorageFilter, setSelectedStorageFilter] = useState("SEMUA");
  const [viewingAnomaliesPage, setViewingAnomaliesPage] = useState(false);
  const [activeTab, setActiveTab] = useState<"dashboard" | "daily" | "yearly" | "plan">(() => {
    const meta = getSyncLocalData<{ activeTab?: "dashboard" | "daily" | "yearly" | "plan" }>("fuel_meta", { activeTab: "dashboard" });
    return meta?.activeTab || "dashboard";
  });
  const [selectedUnitFilter, setSelectedUnitFilter] = useState<string[]>([]);

  // File Input and Dialog Reference
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Google Sheets Integration States
  const [isGoogleSheetsActive, setIsGoogleSheetsActive] = useState(false);
  const [googleUser, setGoogleUser] = useState<any>(null);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [sheetsAccessToken, setSheetsAccessToken] = useState<string | null>(null);
  const [spreadsheetUrl, setSpreadsheetUrl] = useState("");
  const [sheetsSpreadsheetId, setSheetsSpreadsheetId] = useState<string | null>(null);
  const [spreadsheetMetadata, setSpreadsheetMetadata] = useState<{ title: string; sheets: string[] } | null>(null);
  const [sheetsSelectedLogTab, setSheetsSelectedLogTab] = useState("");
  const [sheetsSelectedPlanTab, setSheetsSelectedPlanTab] = useState("");

  // Firestore Active Dataset Sync Status
  const [firestoreSyncStatus, setFirestoreSyncStatus] = useState<{
    isSynced: boolean;
    isLoading: boolean;
    lastUpdated?: string;
    recordCount?: number;
    fileName?: string;
    uploadedBy?: string;
  }>({ isSynced: false, isLoading: true });

  // Initialize Google Auth
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setGoogleUser(user);
        setSheetsAccessToken(token);
      },
      () => {
        setGoogleUser(null);
        setSheetsAccessToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  // Real-time Firestore Active Dataset synchronization & automatic restoration
  useEffect(() => {
    // Dynamic browser tab favicon & title ensure
    document.title = "DASHBOARD FUEL ANALYSIS PT. WBS";
    const faviconUrl = "https://res.cloudinary.com/dgjnlxf69/image/upload/v1787534678/Logo_Fuel_Monitor_air6wr.png";
    let iconLink = document.querySelector<HTMLLinkElement>("link[rel~='icon']");
    if (!iconLink) {
      iconLink = document.createElement("link");
      iconLink.rel = "icon";
      document.head.appendChild(iconLink);
    }
    iconLink.href = faviconUrl;
    let appleIconLink = document.querySelector<HTMLLinkElement>("link[rel='apple-touch-icon']");
    if (appleIconLink) {
      appleIconLink.href = faviconUrl;
    }
  }, []);

  useEffect(() => {
    let isInitialLoad = true;

    // 1. Subscribe to active dataset in Firestore
    const unsubscribeActive = subscribeToActiveDataset(
      (dataset) => {
        if (dataset && dataset.records && dataset.records.length > 0) {
          const currentLocal = getSyncLocalData<FuelRecord[]>("fuel_records", []);
          // Combine local records from other months with dataset records
          const datasetMonths = new Set(dataset.records.map(r => r.tanggal?.substring(0, 7)).filter(Boolean));
          const preservedOtherMonths = currentLocal.filter(r => {
            const ym = r.tanggal?.substring(0, 7);
            return ym && !datasetMonths.has(ym);
          });
          const combined = [...preservedOtherMonths, ...dataset.records];
          const mergedRecords = mergeWithYearlyRecords(combined);

          setRecords(mergedRecords);
          if (dataset.plans && Object.keys(dataset.plans).length > 0) {
            setPlans(dataset.plans);
          }

          // Restore date range from fuel_meta if user selected a specific month, otherwise use dataset
          const savedMeta = getSyncLocalData<{ startDate?: string; endDate?: string }>("fuel_meta", {});
          if (savedMeta?.startDate && savedMeta?.endDate) {
            setStartDate(savedMeta.startDate);
            setEndDate(savedMeta.endDate);
          } else {
            if (dataset.startDate) setStartDate(dataset.startDate);
            if (dataset.endDate) setEndDate(dataset.endDate);
          }

          setFirestoreSyncStatus({
            isSynced: true,
            isLoading: false,
            lastUpdated: dataset.uploadedAt,
            recordCount: dataset.records.length,
            fileName: dataset.fileName,
            uploadedBy: dataset.uploadedBy
          });

          // Sync local storage cache for instant offline fallback
          saveLocalData("fuel_records", mergedRecords);
          if (dataset.plans) saveLocalData("fuel_plans", dataset.plans);

          if (isInitialLoad) {
            setFileFeedback({
              type: "success",
              message: `Terhubung ke Firebase Firestore: Memuat dataset aktif "${dataset.fileName}" (${mergedRecords.length} baris data diesel).`
            });
            isInitialLoad = false;
          }
        } else {
          // No active dataset on Firestore yet, try loading local session
          setFirestoreSyncStatus({
            isSynced: false,
            isLoading: false
          });
          getLocalData<FuelRecord[]>("fuel_records").then((savedRecords) => {
            if (savedRecords && savedRecords.length > 0) {
              setRecords(mergeWithYearlyRecords(savedRecords));
            } else {
              setRecords(INITIAL_FUEL_DATA);
            }
          });
        }
      },
      (err) => {
        console.warn("Firestore dataset subscription notice:", err);
        setFirestoreSyncStatus({ isSynced: false, isLoading: false });
      }
    );

    // 2. Also subscribe to monthly reports to recover records from any separately uploaded months (e.g. September, Juni, Mei)
    const unsubscribeMonthly = subscribeToMonthlyReports((reports) => {
      if (reports && reports.length > 0) {
        let hasNewRecords = false;
        const extraLogs: FuelRecord[] = [];
        reports.forEach(rep => {
          if (rep.records && Array.isArray(rep.records) && rep.records.length > 0) {
            // Check if incoming records have collapsed onto a single date (e.g. 2026-xx-15)
            const uniqueDates = new Set(rep.records.map(r => r.tanggal).filter(Boolean));
            let sanitizedRecords = rep.records;
            if (uniqueDates.size <= 1) {
              const mIdx = rep.monthIndex !== undefined && rep.monthIndex >= 0 ? rep.monthIndex : 0;
              const mPad = String(mIdx + 1).padStart(2, "0");
              const daysInMonth = new Date(2026, mIdx + 1, 0).getDate() || 30;
              sanitizedRecords = rep.records.map((r, rIdx) => {
                const dayNum = Math.min(daysInMonth, Math.max(1, Math.floor((rIdx / Math.max(1, rep.records!.length)) * daysInMonth) + 1));
                const dayStr = String(dayNum).padStart(2, "0");
                return {
                  ...r,
                  tanggal: `2026-${mPad}-${dayStr}`,
                  jam: formatExcelTime(r.jam)
                };
              });
            } else {
              sanitizedRecords = rep.records.map(r => ({
                ...r,
                jam: formatExcelTime(r.jam)
              }));
            }
            extraLogs.push(...sanitizedRecords);
            hasNewRecords = true;
          } else if (rep.unitSummaries && Array.isArray(rep.unitSummaries) && rep.unitSummaries.length > 0) {
            // Guarantee full daily records if only unit aggregates were stored
            const mIdx = rep.monthIndex !== undefined && rep.monthIndex >= 0 ? rep.monthIndex : 8;
            const mPad = String(mIdx + 1).padStart(2, "0");
            const ym = `2026-${mPad}`;
            const daysInMonth = new Date(2026, mIdx + 1, 0).getDate() || 30;

            rep.unitSummaries.forEach(u => {
              if (u.totalVolume <= 0 && u.totalHours <= 0) return;
              const dailyVol = Number((u.totalVolume / daysInMonth).toFixed(1));
              const dailyHm = Number((u.totalHours / daysInMonth).toFixed(1));
              for (let d = 1; d <= daysInMonth; d++) {
                const dayStr = String(d).padStart(2, "0");
                const hmBefore = Number((1000 + (d - 1) * dailyHm).toFixed(1));
                const hmAfter = Number((hmBefore + dailyHm).toFixed(1));
                extraLogs.push(processRecord({
                  id: `synced-${ym}-${dayStr}-${u.idAlat}`,
                  tanggal: `${ym}-${dayStr}`,
                  storage: "Storage Utama Central",
                  idAlat: u.idAlat,
                  egy: u.egy || deriveEgy(u.idAlat, u.typeAlat || ""),
                  typeAlat: u.typeAlat || deriveEquipmentType(u.idAlat),
                  hmSebelum: hmBefore,
                  hmSaatIni: hmAfter,
                  volumeFuel: dailyVol,
                  operator: "Operator Lapangan",
                  fuelman: "Fuelman Onsite",
                  shift: (d % 2 === 0) ? "Shift 1 - Siang" : "Shift 2 - Malam",
                  jam: (d % 2 === 0) ? "10:30" : "21:45"
                }));
              }
            });
            hasNewRecords = true;
          }
        });

        if (hasNewRecords && extraLogs.length > 0) {
          setRecords(prev => {
            // Calculate day count per month in prev to avoid overwriting rich daily records with worse single-day data
            const monthDayCountsPrev: Record<string, Set<string>> = {};
            prev.forEach(r => {
              const ym = r.tanggal?.substring(0, 7);
              if (ym) {
                if (!monthDayCountsPrev[ym]) monthDayCountsPrev[ym] = new Set();
                monthDayCountsPrev[ym].add(r.tanggal);
              }
            });

            const extraMonthsToReplace = new Set<string>();
            const monthDayCountsExtra: Record<string, Set<string>> = {};
            extraLogs.forEach(r => {
              const ym = r.tanggal?.substring(0, 7);
              if (ym) {
                if (!monthDayCountsExtra[ym]) monthDayCountsExtra[ym] = new Set();
                monthDayCountsExtra[ym].add(r.tanggal);
              }
            });

            Object.keys(monthDayCountsExtra).forEach(ym => {
              const prevDays = monthDayCountsPrev[ym]?.size || 0;
              const extraDays = monthDayCountsExtra[ym]?.size || 0;
              // If incoming has >= 10 days of records or prev had fewer days, replace
              if (extraDays >= 10 || extraDays >= prevDays || prevDays === 0) {
                extraMonthsToReplace.add(ym);
              }
            });

            const filteredPrev = prev.filter(r => {
              const ym = r.tanggal?.substring(0, 7);
              return !ym || !extraMonthsToReplace.has(ym);
            });
            const validIncoming = extraLogs.filter(r => {
              const ym = r.tanggal?.substring(0, 7);
              return ym && extraMonthsToReplace.has(ym);
            });
            const merged = mergeWithYearlyRecords([...filteredPrev, ...validIncoming]);
            saveLocalData("fuel_records", merged);
            return merged;
          });
        }
      }
    });

    return () => {
      unsubscribeActive();
      unsubscribeMonthly();
    };
  }, []);

  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    setFileFeedback({ type: null, message: "" });
    try {
      const result = await googleSignIn();
      if (result) {
        setGoogleUser(result.user);
        setSheetsAccessToken(result.accessToken);
        setFileFeedback({
          type: "success",
          message: `Berhasil login! Akun Google terhubung sebagai: ${result.user.displayName || result.user.email}`
        });
      }
    } catch (err: any) {
      console.error("Gagal Google Login:", err);
      setFileFeedback({
        type: "error",
        message: `Gagal menghubungkan Google Account: ${err.message || 'Pemberian izin dibatalkan.'}`
      });
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleGoogleLogout = async () => {
    setFileFeedback({ type: null, message: "" });
    try {
      await logout();
      setGoogleUser(null);
      setSheetsAccessToken(null);
      setSheetsSpreadsheetId(null);
      setSpreadsheetMetadata(null);
      setFileFeedback({
        type: "success",
        message: "Berhasil memutuskan tautan Google Account."
      });
    } catch (err: any) {
      console.error("Gagal Google Logout:", err);
    }
  };

  const handleLoadSpreadsheetMetadata = async () => {
    if (!spreadsheetUrl.trim()) {
      setFileFeedback({
        type: "error",
        message: "Masukkan tautan Google Spreadsheet terlebih dahulu."
      });
      return;
    }
    const sId = extractSpreadsheetId(spreadsheetUrl);
    if (!sId) {
      setFileFeedback({
        type: "error",
        message: "Format Link Google Spreadsheet tidak dikenali. Harap salin link lengkap dari browser Anda."
      });
      return;
    }
    
    if (!sheetsAccessToken) {
      setFileFeedback({
        type: "error",
        message: "Sesi Google Akun belum terhubung. Silakan klik hubungkan akun terlebih dahulu."
      });
      return;
    }

    setGoogleLoading(true);
    setFileFeedback({ type: null, message: "" });

    try {
      const meta = await fetchSpreadsheetMetadata(sId, sheetsAccessToken);
      setSheetsSpreadsheetId(sId);
      setSpreadsheetMetadata(meta);
      
      const sheetsList = meta.sheets || [];
      let logTab = "";
      if (sheetsList.includes("Issued")) {
        logTab = "Issued";
        setSheetsSelectedLogTab("Issued");
      } else {
        logTab = sheetsList.find(s => s !== "List & FC") || sheetsList[0] || "";
        setSheetsSelectedLogTab(logTab);
      }
      
      let planTab = "";
      if (sheetsList.includes("List & FC")) {
        planTab = "List & FC";
        setSheetsSelectedPlanTab("List & FC");
      } else {
        setSheetsSelectedPlanTab("");
      }

      // Automatically sync and import data without needing another click!
      await handleImportGoogleSheetData(logTab, planTab, sId);

    } catch (err: any) {
      console.error(err);
      const isFailedToFetch = err && (String(err.message || "").includes("Failed to fetch") || String(err || "").includes("Failed to fetch") || String(err.message || "").includes("fetch"));
      setFileFeedback({
        type: "error",
        message: isFailedToFetch 
          ? "Koneksi ke Google API terputus (Failed to fetch). Ini biasanya terjadi jika login Google akun Anda kedaluwarsa, belum menyetujui izin baca spreadsheet, atau diblokir oleh ekstensi browser AdBlock/Shields."
          : `Gagal menyinkronkan Spreadsheet: ${err.message || err}`
      });
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleImportGoogleSheetData = async (
    overrideLogTab?: string,
    overridePlanTab?: string,
    overrideSId?: string
  ) => {
    const sId = overrideSId || sheetsSpreadsheetId;
    const logTab = overrideLogTab || sheetsSelectedLogTab;
    const planTab = overridePlanTab !== undefined ? overridePlanTab : sheetsSelectedPlanTab;
    const token = sheetsAccessToken;

    if (!sId || !logTab || !token) {
      setFileFeedback({
        type: "error",
        message: "Harap masukkan Spreadsheet dan hubungkan tab sheet terlebih dahulu."
      });
      return;
    }

    setIsProcessingFile(true);
    setFileFeedback({ type: null, message: "" });

    try {
      // 1. Fetch Plan Sheet values if chosen
      let plansExtracted: Record<string, { idAlat: string; typeAlat: string; planFuelBurn: number }> = {};
      if (planTab) {
        try {
          const fcRows = await fetchSheetValues(sId, planTab, token);
          fcRows.forEach((row) => {
            if (!row || row.length < 4) return;
            const cellA = row[0];
            const cellB = row[1];
            const cellD = row[3];
            
            if (cellA && cellB && cellD !== undefined && cellD !== null) {
              const idAlatStr = String(cellA).trim().toUpperCase();
              const typeAlatStr = String(cellB).trim();
              const planValue = parseFloat(cellD);
              const isHeaderRow = idAlatStr === "NOMOR UNIT" || idAlatStr === "UNIT" || idAlatStr.includes("ALAT") || idAlatStr === "A";
              
              if (idAlatStr && !isHeaderRow && !isNaN(planValue)) {
                plansExtracted[idAlatStr] = {
                  idAlat: idAlatStr,
                  typeAlat: typeAlatStr,
                  planFuelBurn: planValue
                };
              }
            }
          });
        } catch (fcErr) {
          console.warn("Gagal mengekstrak data plan dari sheet:", fcErr);
        }
      }

      // 2. Fetch Log Sheet values
      const logRows = await fetchSheetValues(sId, logTab, token);
      if (logRows.length === 0) {
        throw new Error(`Sheet "${logTab}" tidak memiliki data apa pun.`);
      }

      // 3. Map values using exact colMap scanning logic
      const isIssuedSheet = logTab.toLowerCase() === "issued" || logTab.toLowerCase().includes("issue");
      
      let colMap = {
        tanggal: 6,                          // Column G (index 6): tanggal
        storage: 7,                          // Column H (index 7): storage pengisian fuel
        idAlat: 8,                           // Column I (index 8): Unit / Equipment ID
        typeAlat: 9,                         // Column J (index 9): Kategori unit
        brandAlat: 10,                       // Column K (index 10): Type.brand unit
        hmSebelum: 11,                       // Column L (index 11): HM pengisian fuel sebelumnya
        hmSaatIni: 12,                       // Column M (index 12): HM pengisian fuel pada tanggal itu
        volumeFuel: 14,                      // Column O (index 14): jumlah fuel yang diisi
        operator: 18,                        // Column S (index 18): nama operator unit
        fuelman: 20,                         // Column U (index 20)
        shift: 21,                           // Column V (index 21)
        jam: 22                              // Column W (index 22)
      };

      let detectedHeaderRowIdx = -1;

      if (isIssuedSheet) {
        let foundHeaderIdx = -1;
        const scanRowsLimit = Math.min(logRows.length, 30);
        for (let r = 0; r < scanRowsLimit; r++) {
          const row = logRows[r];
          if (!row || !Array.isArray(row)) continue;
          let hits = 0;
          row.forEach((cell) => {
            if (cell === undefined || cell === null) return;
            const str = String(cell).toLowerCase().trim();
            if (
              str.includes("tanggal") || 
              str.includes("unit") || 
              str === "kategori" || 
              str.includes("hm") || 
              str.includes("fuel") ||
              str.includes("jam")
            ) {
              hits++;
            }
          });
          if (hits >= 3) {
            foundHeaderIdx = r;
            break;
          }
        }
        detectedHeaderRowIdx = foundHeaderIdx;
      } else {
        let bestHeaderRowIdx = -1;
        const scanRowsLimit = Math.min(logRows.length, 30);
        let maxMatches = 0;
        let bestRowColMap = { ...colMap };

        for (let r = 0; r < scanRowsLimit; r++) {
          const row = logRows[r];
          if (!row || !Array.isArray(row)) continue;
          
          let matches = 0;
          let tempMap = { ...colMap };
          
          row.forEach((cell, cIdx) => {
            if (cell === undefined || cell === null) return;
            const str = String(cell).toLowerCase().trim();
            if (!str) return;
            
            if (str === "tanggal" || str === "tgl" || str === "date") {
              tempMap.tanggal = cIdx;
              matches++;
            } else if (
              str === "tempat" || 
              str === "storage" || 
              str === "fuel storage" || 
              str === "lokasi" || 
              str === "gate" || 
              str.includes("storage") || 
              str.includes("tempat") || 
              str.includes("gate") ||
              str.includes("lokasi")
            ) {
              tempMap.storage = cIdx;
              matches++;
            } else if (
              str === "unit" || 
              str === "nomor unit" || 
              str === "no unit" || 
              str === "id alat" || 
              str === "id_alat" || 
              str === "unit id" || 
              str === "no. unit" || 
              str === "unit_id" || 
              str.includes("nomor unit") ||
              str === "no_unit"
            ) {
              tempMap.idAlat = cIdx;
              matches++;
            } else if (
              str === "kategori" || 
              str === "type" || 
              str === "type alat" || 
              str === "type alat berat" || 
              str === "jenis alat" || 
              str === "jenis" || 
              str === "type_alat" || 
              str === "type_alat_berat" ||
              str.includes("kategori") ||
              str.includes("type alat") ||
              str === "type alat berat / kategori"
            ) {
              tempMap.typeAlat = cIdx;
              matches++;
            } else if (
              str.includes("hm sebelum") || 
              str.includes("hm sblm") || 
              str.includes("hm awal") || 
              str.includes("previous hm") || 
              str.includes("prev hm") || 
              str === "hm_sebelumnya" ||
              str === "hm sbl"
            ) {
              tempMap.hmSebelum = cIdx;
              matches++;
            } else if (
              str.includes("hm saat ini") || 
              str.includes("hm sesudah") || 
              str.includes("hm akhir") || 
              str.includes("hm_saat_ini") || 
              str.includes("hm_sesudah") || 
              str.includes("hm sesdh") || 
              str.includes("hm kini") ||
              str === "hm ses" ||
              str === "hm_saat_ini"
            ) {
              tempMap.hmSaatIni = cIdx;
              matches++;
            } else if (
              str.includes("volume") || 
              str.includes("fuel") || 
              str.includes("liter") || 
              str === "vol_fuel" || 
              str === "qty" || 
              str === "vol" || 
              str === "volume fuel (liter)" ||
              str === "jumlah" ||
              str === "jumlah (liter)" ||
              str === "liter"
            ) {
              tempMap.volumeFuel = cIdx;
              matches++;
            } else if (
              str === "operator" || 
              str === "nama operator" || 
              str === "driver" ||
              str.includes("operator") ||
              str.includes("driver")
            ) {
              tempMap.operator = cIdx;
              matches++;
            } else if (
              str === "fuelman" || 
              str === "pengisi" || 
              str === "petugas" || 
              str === "nama fuelman" ||
              str.includes("fuelman")
            ) {
              tempMap.fuelman = cIdx;
              matches++;
            } else if (
              str === "shift" || 
              str.includes("group") ||
              str === "regu"
            ) {
              tempMap.shift = cIdx;
              matches++;
            } else if (
              str === "jam" || 
              str === "waktu" || 
              str.includes("jam pengisian") || 
              str.includes("time") || 
              str === "jam pengisian fuel"
            ) {
              tempMap.jam = cIdx;
              matches++;
            }
          });

          if (matches > maxMatches) {
            maxMatches = matches;
            bestHeaderRowIdx = r;
            bestRowColMap = tempMap;
          }
        }

        if (maxMatches >= 2) {
          colMap = bestRowColMap;
          detectedHeaderRowIdx = bestHeaderRowIdx;
        }
      }

      const startRowIndex = isIssuedSheet ? 108 : (detectedHeaderRowIdx !== -1 ? detectedHeaderRowIdx + 1 : 0);
      const parsed: FuelRecord[] = [];

      logRows.forEach((row, index) => {
        if (index < startRowIndex) return;
        if (!row || row.length < Math.max(2, colMap.idAlat + 1)) return;
        
        const isHeader = row.some(cell => {
          if (typeof cell !== "string") return false;
          const low = cell.toLowerCase();
          return low.includes("tanggal") || low.includes("previous hh") || low.includes("operator");
        });
        if (isHeader) return;

        const getCell = (idx: number, def = "") => {
          if (idx === -1 || idx >= row.length) return def;
          return row[idx] !== undefined && row[idx] !== null ? String(row[idx]).trim() : def;
        };

        const getFloatCell = (idx: number, def = 0) => {
          if (idx === -1 || idx >= row.length) return def;
          const val = parseFloat(row[idx]);
          return isNaN(val) ? def : val;
        };

        const dateCellIdx = colMap.tanggal;
        const tanggal = dateCellIdx !== -1 && dateCellIdx < row.length
          ? normalizeDateToYMD(row[dateCellIdx])
          : "";
        
        if (!tanggal) return;
        
        const idAlat = getCell(colMap.idAlat).toUpperCase();
        if (!idAlat) return;
        
        const storage = getCell(colMap.storage, "Storage Utama Central");
        
        // Map strictly to Kategori Unit (column J)
        const kategoriVal = getCell(colMap.typeAlat, "").trim();
        const typeAlat = kategoriVal || "Excavator PC200";

        const hmSebelum = getFloatCell(colMap.hmSebelum, 0);
        const hmSaatIni = getFloatCell(colMap.hmSaatIni, 0);
        const volumeFuel = getFloatCell(colMap.volumeFuel, 0);
        const operator = getCell(colMap.operator, "Operator Lapangan");
        const fuelman = getCell(colMap.fuelman, "Fuelman Onsite");
        const shift = getCell(colMap.shift, "Shift 1 - Siang");
        const jam = getCell(colMap.jam, "12:00");
        
        parsed.push(processRecord({
          id: `sheets-row-${index}-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          tanggal,
          storage,
          idAlat,
          typeAlat,
          hmSebelum,
          hmSaatIni,
          volumeFuel,
          operator,
          fuelman,
          shift,
          jam
        }));
      });

      if (parsed.length === 0) {
        throw new Error(`Tidak ada data pengisian diesel yang dapat dipetakan dari sheet "${logTab}".`);
      }

      if (Object.keys(plansExtracted).length > 0) {
        setPlans(plansExtracted);
      }
      const mergedParsed = mergeWithYearlyRecords(parsed);
      setRecords(mergedParsed);
      setSelectedEgyFilter("SEMUA");
      setSelectedStorageFilter("SEMUA");

      const hasPlansMsg = Object.keys(plansExtracted).length > 0 
        ? ` dan ${Object.keys(plansExtracted).length} pembanding target plan dari sheet "${planTab}"` 
        : "";
      
      setFileFeedback({
        type: "success",
        message: `Berhasil tersinkronisasi! Menarik ${parsed.length} data pengisian diesel dari Google Sheet "${logTab}"${hasPlansMsg} secara REAL-TIME!`
      });

      // Auto adjust date bounds
      const validDates = parsed.map(p => p.tanggal).filter(t => t);
      if (validDates.length > 0) {
        const sorted = [...validDates].sort();
        setStartDate(sorted[0]);
        setEndDate(sorted[sorted.length - 1]);

        saveLocalData("fuel_records", parsed);
        saveLocalData("fuel_plans", plansExtracted);
        saveLocalData("fuel_meta", {
          startDate: sorted[0],
          endDate: sorted[sorted.length - 1],
          fileName: `Google Sheet: ${logTab}`,
          activeTab: "dashboard"
        });

        // Persist to Cloud Firestore Active Dataset
        saveActiveDatasetToFirestore({
          records: parsed,
          plans: plansExtracted,
          startDate: sorted[0],
          endDate: sorted[sorted.length - 1],
          fileName: `Google Sheet: ${logTab}`,
          userEmail: googleUser?.email
        }).catch(fsErr => console.warn("Firestore dataset autosave notice:", fsErr));
      }
    } catch (err: any) {
      console.error(err);
      const isFailedToFetch = err && (String(err.message || "").includes("Failed to fetch") || String(err || "").includes("Failed to fetch") || String(err.message || "").includes("fetch"));
      setFileFeedback({
        type: "error",
        message: isFailedToFetch
          ? "Koneksi ke Google API terputus (Failed to fetch). Ini biasanya terjadi jika login Google akun Anda kedaluwarsa, belum menyetujui izin baca spreadsheet, atau diblokir oleh ekstensi browser AdBlock/Shields."
          : `Gagal menarik data Google Sheet: ${err.message || 'Harap periksa pengaturan sheet dan format kolom.'}`
      });
    } finally {
      setIsProcessingFile(false);
    }
  };

  // Extract unique values for filter dropdowns
  const uniqueEgys = useMemo(() => {
    const egys = new Set<string>();
    records.forEach(r => {
      const egy = r.egy || deriveEgy(r.idAlat, r.typeAlat);
      if (egy) egys.add(egy);
    });
    return Array.from(egys).sort();
  }, [records]);

  // Extract units matching the selected Egy
  const availableUnitsForEgy = useMemo<UnitItem[]>(() => {
    const map = new Map<string, UnitItem>();
    records.forEach(r => {
      if (!r.idAlat) return;
      const rEgy = r.egy || deriveEgy(r.idAlat, r.typeAlat);
      if (selectedEgyFilter === "SEMUA" || rEgy === selectedEgyFilter) {
        const canon = getCanonicalUnitId(r.idAlat).toUpperCase();
        if (!map.has(canon)) {
          map.set(canon, {
            idAlat: r.idAlat,
            egy: rEgy,
            typeAlat: r.typeAlat || ""
          });
        }
      }
    });
    return Array.from(map.values()).sort((a, b) => 
      a.idAlat.localeCompare(b.idAlat, undefined, { numeric: true })
    );
  }, [records, selectedEgyFilter]);

  // Automatically select all units when EGY filter changes or records change
  useEffect(() => {
    const allIds = availableUnitsForEgy.map(u => getCanonicalUnitId(u.idAlat).toUpperCase());
    setSelectedUnitFilter(allIds);
  }, [selectedEgyFilter, availableUnitsForEgy]);

  const uniqueStorages = useMemo(() => {
    const storages = new Set<string>();
    records.forEach(r => storages.add(r.storage));
    return Array.from(storages).sort();
  }, [records]);

  // Derive unique months available across the uploaded/synced dataset
  const availableMonths = useMemo(() => {
    const monthsMap = new Map<string, { label: string; yearMonth: string; startDate: string; endDate: string; recordCount: number }>();
    const monthNames = [
      "Januari", "Februari", "Maret", "April", "Mei", "Juni",
      "Juli", "Agustus", "September", "Oktober", "November", "Desember"
    ];

    records.forEach(r => {
      if (!r.tanggal || r.tanggal.length < 7) return;
      const ym = r.tanggal.substring(0, 7); // e.g. "2026-07"
      const parts = ym.split("-");
      if (parts.length !== 2) return;
      const year = parts[0];
      const mIdx = parseInt(parts[1], 10) - 1;
      const mName = (mIdx >= 0 && mIdx < 12) ? monthNames[mIdx] : ym;
      const label = `${mName} ${year}`;

      if (!monthsMap.has(ym)) {
        // Calculate last day of month
        const lastDay = new Date(parseInt(year, 10), mIdx + 1, 0).getDate();
        const startStr = `${ym}-01`;
        const endStr = `${ym}-${String(lastDay).padStart(2, "0")}`;
        monthsMap.set(ym, {
          label,
          yearMonth: ym,
          startDate: startStr,
          endDate: endStr,
          recordCount: 1
        });
      } else {
        const item = monthsMap.get(ym)!;
        item.recordCount += 1;
      }
    });

    return Array.from(monthsMap.values()).sort((a, b) => a.yearMonth.localeCompare(b.yearMonth));
  }, [records]);

  const selectMonth = (ym: string) => {
    const target = availableMonths.find(m => m.yearMonth === ym);
    if (target) {
      setStartDate(target.startDate);
      setEndDate(target.endDate);
      setSelectedEgyFilter("SEMUA");
      setSelectedStorageFilter("SEMUA");
      setSelectedUnitFilter([]);
      saveLocalData("fuel_meta", {
        startDate: target.startDate,
        endDate: target.endDate,
        activeTab: "dashboard"
      });
    } else {
      // Deterministic calculation if availableMonths hasn't updated or target is missing
      const parts = ym.split("-");
      const year = parseInt(parts[0], 10) || 2026;
      const monthNum = parseInt(parts[1], 10) || 9;
      const lastDay = new Date(year, monthNum, 0).getDate();
      const sDate = `${year}-${String(monthNum).padStart(2, "0")}-01`;
      const eDate = `${year}-${String(monthNum).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;
      setStartDate(sDate);
      setEndDate(eDate);
      setSelectedEgyFilter("SEMUA");
      setSelectedStorageFilter("SEMUA");
      setSelectedUnitFilter([]);
      saveLocalData("fuel_meta", {
        startDate: sDate,
        endDate: eDate,
        activeTab: "dashboard"
      });
    }
  };

  // Apply filters to get ACTIVE working records for calculation
  const filteredRecords = useMemo(() => {
    const unitSet = new Set(selectedUnitFilter.map(id => id.toUpperCase()));
    const allAvailableCanonIds = availableUnitsForEgy.map(u => getCanonicalUnitId(u.idAlat).toUpperCase());
    const isAllSelected = selectedUnitFilter.length === 0 || allAvailableCanonIds.every(id => unitSet.has(id));

    return records.filter(r => {
      // Date filter match
      const dateMatch = (!startDate || r.tanggal >= startDate) && (!endDate || r.tanggal <= endDate);
      
      // Egy filter match
      const rEgy = r.egy || deriveEgy(r.idAlat, r.typeAlat);
      const egyMatch = selectedEgyFilter === "SEMUA" || rEgy === selectedEgyFilter;

      // Storage match
      const storageMatch = selectedStorageFilter === "SEMUA" || r.storage === selectedStorageFilter;

      // Unit filter match
      let unitMatch = true;
      if (!isAllSelected && r.idAlat) {
        const canon = getCanonicalUnitId(r.idAlat).toUpperCase();
        unitMatch = unitSet.has(canon);
      }

      return dateMatch && egyMatch && storageMatch && unitMatch;
    });
  }, [records, startDate, endDate, selectedEgyFilter, selectedStorageFilter, selectedUnitFilter, availableUnitsForEgy]);

  // Compare actual vs plan (List & FC and Egy Plans)
  const unitComparisons = useMemo(() => {
    // 1. Group active records by Unit ID
    // We only use non-anomaly records within the filtered date range and type filters (strictly exclude rental units with selisihHm <= 0)
    const aggregates: Record<string, { idAlat: string; egy: string; typeAlat: string; totalVolume: number; totalHours: number; recordCount: number }> = {};
    
    filteredRecords.forEach(r => {
      if (r.isAnomaly || r.selisihHm <= 0) return;
      const key = r.idAlat.toUpperCase();
      const resolvedEgy = cleanEgyName(deriveEgy(r.idAlat, r.egy || r.typeAlat) || r.egy || "LAINNYA");
      if (!aggregates[key]) {
        aggregates[key] = {
          idAlat: r.idAlat,
          egy: resolvedEgy,
          typeAlat: r.typeAlat,
          totalVolume: 0,
          totalHours: 0,
          recordCount: 0
        };
      }
      aggregates[key].totalVolume += r.volumeFuel;
      aggregates[key].totalHours += r.selisihHm;
      aggregates[key].recordCount += 1;
    });

    return Object.values(aggregates)
      .filter(item => item.totalHours > 0)
      .map(item => {
        const avgActual = item.totalHours > 0 ? Number((item.totalVolume / item.totalHours).toFixed(2)) : 0;
        const resolved = resolvePlanForUnit(item.idAlat, item.egy, item.typeAlat, plans, egyPlans);
        const planValue = resolved.planFuelBurn;
        const deviation = planValue > 0 ? avgActual - planValue : 0;
        const deviationPct = planValue > 0 ? (deviation / planValue) * 100 : 0;
        const isOver = deviation > 0.01;

        return {
          idAlat: item.idAlat,
          egy: item.egy,
          typeAlat: item.typeAlat,
          actual: avgActual,
          plan: planValue,
          planSource: resolved.source,
          deviation,
          deviationPct,
          isOver,
          totalVolume: item.totalVolume,
          totalHours: item.totalHours,
          recordCount: item.recordCount
        };
      });
  }, [filteredRecords, plans, egyPlans]);

  // List of only over-plan units
  const overPlanUnits = useMemo(() => {
    return unitComparisons
      .filter(u => u.isOver)
      .sort((a, b) => b.deviation - a.deviation);
  }, [unitComparisons]);

  // Extract reference date from the selected range, normally latest in active records
  const referenceDate = useMemo(() => {
    if (filteredRecords.length === 0) {
      if (records.length === 0) return "";
      // Fallback: get absolute latest date in full database
      const sorted = [...records].sort((a,b) => b.tanggal.localeCompare(a.tanggal));
      return sorted[0].tanggal;
    }
    // Get latest date in filtered list
    const sorted = [...filteredRecords].sort((a,b) => b.tanggal.localeCompare(a.tanggal));
    return sorted[0].tanggal;
  }, [records, filteredRecords]);

  // Dynamic Metrics: Daily, Month to Date (MTD), Year to Date (YTD) based on referenceDate
  const metrics = useMemo(() => {
    if (!referenceDate) {
      return {
        daily: { average: 0, fuel: 0, hours: 0, count: 0, anomalies: 0 },
        mtd: { average: 0, fuel: 0, hours: 0, count: 0, anomalies: 0 },
        ytd: { average: 0, fuel: 0, hours: 0, count: 0, anomalies: 0 }
      };
    }

    const refYear = referenceDate.substring(0, 4);
    const refMonth = referenceDate.substring(5, 7); // MM
    
    // Grab corresponding subsets
    const dailySubset = records.filter(r => r.tanggal === referenceDate);
    const mtdSubset = records.filter(r => {
      const year = r.tanggal.substring(0, 4);
      const month = r.tanggal.substring(5, 7);
      return year === refYear && month === refMonth && r.tanggal <= referenceDate;
    });
    const ytdSubset = records.filter(r => {
      const year = r.tanggal.substring(0, 4);
      return year === refYear && r.tanggal <= referenceDate;
    });

    const calculateSubsetMetrics = (subset: FuelRecord[]) => {
      const valids = subset.filter(r => !r.isAnomaly);
      const anomalies = subset.filter(r => r.isAnomaly).length;

      const totalFuel = valids.reduce((acc, r) => acc + r.volumeFuel, 0);
      const totalHours = valids.reduce((acc, r) => acc + r.selisihHm, 0);
      const fuelBurnSum = valids.reduce((acc, r) => acc + r.fuelBurnRate, 0);
      
      // Calculate true weighted operational fleet fuel burn rate (Total Liter / Total Jam Kerja)
      const averageRate = totalHours > 0 
        ? Number((totalFuel / totalHours).toFixed(2)) 
        : (valids.length > 0 ? Number((fuelBurnSum / valids.length).toFixed(2)) : 0);

      return {
        average: averageRate,
        fuel: Number(totalFuel.toFixed(1)),
        hours: Number(totalHours.toFixed(1)),
        count: subset.length,
        anomalies
      };
    };

    return {
      daily: calculateSubsetMetrics(dailySubset),
      mtd: calculateSubsetMetrics(mtdSubset),
      ytd: calculateSubsetMetrics(ytdSubset)
    };
  }, [records, referenceDate]);

  const handleResetToSample = () => {
    clearAllLocalData();
    deleteActiveDatasetFromFirestore().catch(e => console.warn("Firestore delete dataset notice:", e));
    setRecords(INITIAL_FUEL_DATA);
    setPlans(INITIAL_PLANS);
    setStartDate("2026-04-01");
    setEndDate("2026-05-27");
    setSelectedEgyFilter("SEMUA");
    setSelectedStorageFilter("SEMUA");
    setFileFeedback({ type: "success", message: "Database kembali menggunakan 25 Log data contoh PT. WAHANA BARA SENTOSA dan mereset active cloud cache." });
  };

  // Date Range Quick selection Presets
  const applyPreset = (preset: "all" | "today" | "last7" | "last30" | "mtd" | "ytd") => {
    // Determine bounds based on maximum date available (2026-05-27 in samples)
    const latestDateStr = records.length > 0 
      ? [...records].sort((a,b) => b.tanggal.localeCompare(a.tanggal))[0].tanggal
      : "2026-05-27";
    
    const latest = new Date(latestDateStr);

    if (preset === "all") {
      setStartDate("2026-04-01");
      setEndDate(latestDateStr);
    } else if (preset === "today") {
      setStartDate(latestDateStr);
      setEndDate(latestDateStr);
    } else if (preset === "last7") {
      const past = new Date(latest.getTime() - 7 * 24 * 60 * 60 * 1000);
      setStartDate(past.toISOString().split('T')[0]);
      setEndDate(latestDateStr);
    } else if (preset === "last30") {
      const past = new Date(latest.getTime() - 30 * 24 * 60 * 60 * 1000);
      setStartDate(past.toISOString().split('T')[0]);
      setEndDate(latestDateStr);
    } else if (preset === "mtd") {
      setStartDate(`${latestDateStr.substring(0, 8)}01`);
      setEndDate(latestDateStr);
    } else if (preset === "ytd") {
      setStartDate(`${latestDateStr.substring(0, 4)}-01-01`);
      setEndDate(latestDateStr);
    }
  };

  // Selection wrapper for two-stage file loading before manual analysis trigger
  const handleFileSelected = (file: File) => {
    setFileFeedback({ type: null, message: "" });
    setSelectedFile(file);
    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    
    if (fileExtension === "csv" || fileExtension === "txt") {
      setFileSheets([]);
      setSelectedLogSheet("");
      setHasPlanSheetPresent(false);
      return;
    }

    // Read workbook sheets list to let player select which one they intend to calculate
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const dataArr = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(dataArr, { type: "array" });
        const sheets = workbook.SheetNames || [];
        setFileSheets(sheets);
        
        let defaultLogSheet = sheets[0] || "";
        const hasPlans = sheets.includes("List & FC");
        setHasPlanSheetPresent(hasPlans);
        
        // Auto-select 'Issued' if present, otherwise select the non-plan sheet
        if (sheets.includes("Issued")) {
          defaultLogSheet = "Issued";
        } else if (hasPlans && sheets.length > 1) {
          defaultLogSheet = sheets.find(s => s !== "List & FC") || defaultLogSheet;
        }
        
        setSelectedLogSheet(defaultLogSheet);
      } catch (err) {
        console.error("Gagal mendeteksi lembar kerja sheet:", err);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // Upgraded custom parser with dynamic column keyword-sensing mapping
  const processUploadedFile = (file: File, targetSheetName: string) => {
    setIsProcessingFile(true);
    setFileFeedback({ type: null, message: "" });
    
    const reader = new FileReader();
    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    
    // Process CSV or raw TXT values
    if (fileExtension === "csv" || fileExtension === "txt") {
      reader.onload = (event) => {
        try {
          const text = event.target?.result as string;
          if (!text) throw new Error("File kosong atau tidak dapat diakses.");
          
          const parsed = parsePastedData(text);
          if (parsed.length === 0) {
            throw new Error("Tidak menemukan baris data pengisian valid. Pastikan format kolom sesuai dengan template Excel.");
          }
          
          const mergedCsv = mergeWithYearlyRecords(parsed);
          setRecords(mergedCsv);
          setSelectedEgyFilter("SEMUA");
          setSelectedStorageFilter("SEMUA");
          setFileFeedback({
            type: "success",
            message: `Berhasil mengimpor & menganalisis ${parsed.length} baris data dari Google Sheets CSV "${file.name}" secara otomatis!`
          });
          
          // Auto-frame range tanggal
          const validDates = parsed.map(p => p.tanggal).filter(t => t);
          if (validDates.length > 0) {
            const sorted = [...validDates].sort();
            setStartDate(sorted[0]);
            setEndDate(sorted[sorted.length - 1]);

            saveLocalData("fuel_records", mergedCsv);
            saveLocalData("fuel_plans", plans);
            saveLocalData("fuel_meta", {
              startDate: sorted[0],
              endDate: sorted[sorted.length - 1],
              fileName: file.name,
              activeTab: "dashboard"
            });

            // Save active dataset to Cloud Firestore
            saveActiveDatasetToFirestore({
              records: parsed,
              plans: plans,
              startDate: sorted[0],
              endDate: sorted[sorted.length - 1],
              fileName: file.name,
              userEmail: googleUser?.email
            }).catch(fsErr => console.warn("Firestore dataset autosave notice:", fsErr));
          }
        } catch (err: any) {
          setFileFeedback({
            type: "error",
            message: `Gagal membaca CSV: ${err.message || 'Harap periksa kecocokan data.'}`
          });
        } finally {
          setIsProcessingFile(false);
          setSelectedFile(null);
        }
      };
      reader.readAsText(file);
      return;
    }
    
    // Process native spreadsheet files via SheetJS (xlsx, xls)
    reader.onload = (event) => {
      try {
        const dataArr = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(dataArr, { type: "array" });
        
        if (workbook.SheetNames.length === 0) {
          throw new Error("Buku kerja Excel tidak memiliki lembar kerja apapun.");
        }
        
        // 1. Parse "List & FC" target values if it exists in workbook
        let plansExtracted: Record<string, { idAlat: string; typeAlat: string; planFuelBurn: number }> = {};
        if (workbook.SheetNames.includes("List & FC")) {
          const fcSheet = workbook.Sheets["List & FC"];
          const fcJson = XLSX.utils.sheet_to_json<any[]>(fcSheet, { header: 1 });
          fcJson.forEach((row) => {
            if (!row || row.length < 4) return;
            const cellA = row[0];
            const cellB = row[1];
            const cellD = row[3];
            
            if (cellA && cellB && cellD !== undefined && cellD !== null) {
              const idAlatStr = String(cellA).trim().toUpperCase();
              const typeAlatStr = String(cellB).trim();
              const planValue = parseFloat(cellD);
              const isHeaderRow = idAlatStr === "NOMOR UNIT" || idAlatStr === "UNIT" || idAlatStr.includes("ALAT") || idAlatStr === "A";
              
              if (idAlatStr && !isHeaderRow && !isNaN(planValue)) {
                plansExtracted[idAlatStr] = {
                  idAlat: idAlatStr,
                  typeAlat: typeAlatStr,
                  planFuelBurn: planValue
                };
              }
            }
          });
        }

        // 2. Select sheet
        let logsSheetName = targetSheetName;
        if (workbook.SheetNames.includes("Issued") && (!logsSheetName || logsSheetName === "List & FC")) {
          logsSheetName = "Issued";
        }
        if (!logsSheetName) {
          logsSheetName = workbook.SheetNames[0];
        }

        const sheet = workbook.Sheets[logsSheetName];
        if (!sheet) {
          throw new Error(`Sheet "${logsSheetName}" tidak ditemukan di file Excel.`);
        }
        
        const rawJson = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1 });
        if (rawJson.length === 0) {
          throw new Error(`Lembar kerja "${logsSheetName}" kosong.`);
        }

        // --- CHOOSE AND SETUP MAPPING ENGINE ---
        const isIssuedSheet = logsSheetName.toLowerCase() === "issued" || logsSheetName.toLowerCase().includes("issue");
        
        let colMap = {
          tanggal: 6,                          // Column G (index 6): tanggal
          storage: 7,                          // Column H (index 7): storage pengisian fuel
          idAlat: 8,                           // Column I (index 8): Unit / Equipment ID
          typeAlat: 9,                         // Column J (index 9): Kategori unit
          brandAlat: 10,                       // Column K (index 10): Type.brand unit
          hmSebelum: 11,                       // Column L (index 11): HM pengisian fuel sebelumnya
          hmSaatIni: 12,                       // Column M (index 12): HM pengisian fuel pada tanggal itu
          volumeFuel: 14,                      // Column O (index 14): jumlah fuel yang diisi
          operator: 18,                        // Column S (index 18): nama operator unit
          fuelman: 20,                         // Column U (index 20)
          shift: 21,                           // Column V (index 21)
          jam: 22                              // Column W (index 22)
        };

        let detectedHeaderRowIdx = -1;

        if (isIssuedSheet) {
          // Strictly lock indices for "Issued" sheet to prevent any header-scanning mismatch or overlaps!
          // We only need to find the header row index to skip the metadata headings properly.
          let foundHeaderIdx = -1;
          const scanRowsLimit = Math.min(rawJson.length, 30);
          for (let r = 0; r < scanRowsLimit; r++) {
            const row = rawJson[r];
            if (!row || !Array.isArray(row)) continue;
            let hits = 0;
            row.forEach((cell) => {
              if (cell === undefined || cell === null) return;
              const str = String(cell).toLowerCase().trim();
              if (
                str.includes("tanggal") || 
                str.includes("unit") || 
                str === "kategori" || 
                str.includes("hm") || 
                str.includes("fuel") ||
                str.includes("jam")
              ) {
                hits++;
              }
            });
            if (hits >= 3) {
              foundHeaderIdx = r;
              break;
            }
          }
          detectedHeaderRowIdx = foundHeaderIdx;
        } else {
          // Fallback parser dynamic scanner for any other formats
          let bestHeaderRowIdx = -1;
          const scanRowsLimit = Math.min(rawJson.length, 30);
          let maxMatches = 0;
          let bestRowColMap = { ...colMap };

          for (let r = 0; r < scanRowsLimit; r++) {
            const row = rawJson[r];
            if (!row || !Array.isArray(row)) continue;
            
            let matches = 0;
            let tempMap = { ...colMap };
            
            row.forEach((cell, cIdx) => {
              if (cell === undefined || cell === null) return;
              const str = String(cell).toLowerCase().trim();
              if (!str) return;
              
              if (str === "tanggal" || str === "tgl" || str === "date") {
                tempMap.tanggal = cIdx;
                matches++;
              } else if (
                str === "tempat" || 
                str === "storage" || 
                str === "fuel storage" || 
                str === "lokasi" || 
                str === "gate" || 
                str.includes("storage") || 
                str.includes("tempat") || 
                str.includes("gate") ||
                str.includes("lokasi")
              ) {
                tempMap.storage = cIdx;
                matches++;
              } else if (
                str === "unit" || 
                str === "nomor unit" || 
                str === "no unit" || 
                str === "id alat" || 
                str === "id_alat" || 
                str === "unit id" || 
                str === "no. unit" || 
                str === "unit_id" || 
                str.includes("nomor unit") ||
                str === "no_unit"
              ) {
                tempMap.idAlat = cIdx;
                matches++;
              } else if (
                str === "kategori" || 
                str === "type" || 
                str === "type alat" || 
                str === "type alat berat" || 
                str === "jenis alat" || 
                str === "jenis" || 
                str === "type_alat" || 
                str === "type_alat_berat" ||
                str.includes("kategori") ||
                str.includes("type alat") ||
                str === "type alat berat / kategori"
              ) {
                tempMap.typeAlat = cIdx;
                matches++;
              } else if (
                str.includes("hm sebelum") || 
                str.includes("hm sblm") || 
                str.includes("hm awal") || 
                str.includes("previous hm") || 
                str.includes("prev hm") || 
                str === "hm_sebelumnya" ||
                str === "hm sbl"
              ) {
                tempMap.hmSebelum = cIdx;
                matches++;
              } else if (
                str.includes("hm saat ini") || 
                str.includes("hm sesudah") || 
                str.includes("hm akhir") || 
                str.includes("hm_saat_ini") || 
                str.includes("hm_sesudah") || 
                str.includes("hm sesdh") || 
                str.includes("hm kini") ||
                str === "hm ses" ||
                str === "hm_saat_ini"
              ) {
                tempMap.hmSaatIni = cIdx;
                matches++;
              } else if (
                str.includes("volume") || 
                str.includes("fuel") || 
                str.includes("liter") || 
                str === "vol_fuel" || 
                str === "qty" || 
                str === "vol" || 
                str === "volume fuel (liter)" ||
                str === "jumlah" ||
                str === "jumlah (liter)" ||
                str === "liter"
              ) {
                tempMap.volumeFuel = cIdx;
                matches++;
              } else if (
                str === "operator" || 
                str === "nama operator" || 
                str === "driver" ||
                str.includes("operator") ||
                str.includes("driver")
              ) {
                tempMap.operator = cIdx;
                matches++;
              } else if (
                str === "fuelman" || 
                str === "pengisi" || 
                str === "petugas" || 
                str === "nama fuelman" ||
                str.includes("fuelman")
              ) {
                tempMap.fuelman = cIdx;
                matches++;
              } else if (
                str === "shift" || 
                str.includes("group") ||
                str === "regu"
              ) {
                tempMap.shift = cIdx;
                matches++;
              } else if (
                str === "jam" || 
                str === "waktu" || 
                str.includes("jam pengisian") || 
                str.includes("time") || 
                str === "jam pengisian fuel"
              ) {
                tempMap.jam = cIdx;
                matches++;
              }
            });

            if (matches > maxMatches) {
              maxMatches = matches;
              bestHeaderRowIdx = r;
              bestRowColMap = tempMap;
            }
          }

          if (maxMatches >= 2) {
            colMap = bestRowColMap;
            detectedHeaderRowIdx = bestHeaderRowIdx;
          }
        }

        const startRowIndex = isIssuedSheet ? 109 : (detectedHeaderRowIdx !== -1 ? detectedHeaderRowIdx + 1 : 0);
        const parsed: FuelRecord[] = [];

        rawJson.forEach((row, index) => {
          if (index < startRowIndex) return; // skip headers (starts at row 110 for Issued sheet)
          if (!row || row.length < Math.max(2, colMap.idAlat + 1)) return;
          
          // Double check to make sure redundant labels are skipped
          const isHeader = row.some(cell => {
            if (typeof cell !== "string") return false;
            const low = cell.toLowerCase();
            return low.includes("tanggal") || low.includes("previous hh") || low.includes("operator");
          });
          if (isHeader) return;
          
          // Safe values extractor
          const getCell = (idx: number, def = "") => {
            if (idx === -1 || idx >= row.length) return def;
            return row[idx] !== undefined && row[idx] !== null ? String(row[idx]).trim() : def;
          };

          const getFloatCell = (idx: number, def = 0) => {
            if (idx === -1 || idx >= row.length) return def;
            const val = parseFloat(row[idx]);
            return isNaN(val) ? def : val;
          };

          // Parse date properly using highly robust shared normalizer
          const dateCellIdx = colMap.tanggal;
          const tanggal = dateCellIdx !== -1 && dateCellIdx < row.length
            ? normalizeDateToYMD(row[dateCellIdx])
            : "";
          
          if (!tanggal) return;
          
          // Prioritize Column I (index 8)
          let idAlat = "";
          if (row.length > 8 && row[8] !== undefined && row[8] !== null) {
            idAlat = String(row[8]).trim().toUpperCase();
          }
          if (!idAlat) {
            idAlat = getCell(colMap.idAlat).toUpperCase();
          }

          // REJECT INVALID UNIT IDS (Decimals, numbers, single letters, totals, formula errors)
          if (!idAlat || idAlat.length < 2) return;
          if (!isNaN(Number(idAlat))) return;
          if (idAlat.includes(".") && !isNaN(parseFloat(idAlat))) return;
          if (idAlat === "C" || idAlat === "A" || idAlat === "B" || idAlat === "D" || idAlat === "TOTAL" || idAlat === "N/A" || idAlat.includes("#REF") || idAlat.includes("DIV/0")) return;
          if (idAlat.toLowerCase().includes("tanggal") || idAlat.toLowerCase().includes("unit") || idAlat.toLowerCase().includes("nomor") || idAlat.toLowerCase().includes("operator")) return;
          
          const storage = getCell(colMap.storage, "Storage Utama Central");
          
          // Map strictly to Kategori Unit (column J) or derive from ID
          const kategoriVal = getCell(colMap.typeAlat, "").trim();
          const typeAlat = kategoriVal || deriveEquipmentType(idAlat);

          const hmSebelum = getFloatCell(colMap.hmSebelum, 0);
          const hmSaatIni = getFloatCell(colMap.hmSaatIni, 0);
          const volumeFuel = getFloatCell(colMap.volumeFuel, 0);
          const operator = getCell(colMap.operator, "Operator Lapangan");
          const fuelman = getCell(colMap.fuelman, "Fuelman Onsite");
          const shift = getCell(colMap.shift, "Shift 1 - Siang");
          const jam = getCell(colMap.jam, "12:00");
          
          parsed.push(processRecord({
            id: `excel-row-${index}-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            tanggal,
            storage,
            idAlat,
            typeAlat,
            hmSebelum,
            hmSaatIni,
            volumeFuel,
            operator,
            fuelman,
            shift,
            jam
          }));
        });
        
        if (parsed.length === 0) {
          throw new Error(`Tidak ada data pengisian diesel yang dapat dipetakan dari sheet "${logsSheetName}".`);
        }
        
        if (Object.keys(plansExtracted).length > 0) {
          setPlans(plansExtracted);
        }
        const mergedDirect = mergeWithYearlyRecords(parsed);
        setRecords(mergedDirect);
        setSelectedEgyFilter("SEMUA");
        setSelectedStorageFilter("SEMUA");
        
        const validDates = parsed.map(p => p.tanggal).filter(t => t);
        if (validDates.length > 0) {
          const sorted = [...validDates].sort();
          setStartDate(sorted[0]);
          setEndDate(sorted[sorted.length - 1]);

          saveLocalData("fuel_records", mergedDirect);
          saveLocalData("fuel_plans", plansExtracted);
          saveLocalData("fuel_meta", {
            startDate: sorted[0],
            endDate: sorted[sorted.length - 1],
            fileName: file.name,
            activeTab: "dashboard"
          });

          // Save complete raw dataset into Cloud Firestore Active Dataset
          saveActiveDatasetToFirestore({
            records: parsed,
            plans: plansExtracted,
            startDate: sorted[0],
            endDate: sorted[sorted.length - 1],
            fileName: file.name,
            userEmail: googleUser?.email
          }).catch(fsErr => console.warn("Firestore raw dataset autosave notice:", fsErr));
        }

        // Auto-save summary to Firebase Firestore for cross-module synchronization
        try {
          const monthNames = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
          let detectedMonthName = "";
          let detectedMonthIdx = 0;
          let detectedYear = 2026;

          if (validDates.length > 0) {
            const firstDateParts = validDates[0].split("-");
            if (firstDateParts.length >= 2) {
              const mNum = parseInt(firstDateParts[1], 10);
              if (!isNaN(mNum) && mNum >= 1 && mNum <= 12) {
                detectedMonthIdx = mNum - 1;
                detectedMonthName = monthNames[detectedMonthIdx];
              }
              const yNum = parseInt(firstDateParts[0], 10);
              if (!isNaN(yNum) && yNum > 2000) {
                detectedYear = yNum;
              }
            }
          }

          if (!detectedMonthName && file.name) {
            const clean = file.name.toLowerCase();
            for (let i = 0; i < monthNames.length; i++) {
              if (clean.includes(monthNames[i].toLowerCase())) {
                detectedMonthName = monthNames[i];
                detectedMonthIdx = i;
                break;
              }
            }
          }

          if (!detectedMonthName) {
            detectedMonthName = "Juni";
            detectedMonthIdx = 5;
          }

          const typeGroupMap: Record<string, { totalVolume: number; totalHours: number; recordCount: number }> = {};
          const unitGroupMap: Record<string, { idAlat: string; egy: string; typeAlat: string; totalVolume: number; totalHours: number; recordCount: number }> = {};

          parsed.forEach(r => {
            const egy = r.egy || deriveEgy(r.idAlat, r.typeAlat);
            const id = r.idAlat || "UNIT-UNKNOWN";
            const t = r.typeAlat || egy;

            // Group by Egy for high-level type summaries
            if (!typeGroupMap[egy]) {
              typeGroupMap[egy] = { totalVolume: 0, totalHours: 0, recordCount: 0 };
            }
            typeGroupMap[egy].totalVolume += r.volumeFuel;
            if (!r.isAnomaly && r.selisihHm > 0) {
              typeGroupMap[egy].totalHours += r.selisihHm;
            }
            typeGroupMap[egy].recordCount += 1;

            // Group by Unit for granular unit summaries
            if (!unitGroupMap[id]) {
              unitGroupMap[id] = { idAlat: id, egy, typeAlat: t, totalVolume: 0, totalHours: 0, recordCount: 0 };
            }
            unitGroupMap[id].totalVolume += r.volumeFuel;
            if (!r.isAnomaly && r.selisihHm > 0) {
              unitGroupMap[id].totalHours += r.selisihHm;
            }
            unitGroupMap[id].recordCount += 1;
          });

          const totalVol = parsed.reduce((sum, r) => sum + r.volumeFuel, 0);
          const totalHrs = parsed.reduce((sum, r) => (!r.isAnomaly && r.selisihHm > 0 ? sum + r.selisihHm : sum), 0);

          const monthlyReportPayload: MonthlyReportData = {
            id: `${detectedYear}_${detectedMonthName}`,
            bulan: detectedMonthName,
            monthIndex: detectedMonthIdx,
            year: detectedYear,
            fileName: file.name,
            uploadedAt: new Date().toISOString(),
            totalVolume: Number(totalVol.toFixed(1)),
            totalHours: Number(totalHrs.toFixed(1)),
            recordCount: parsed.length,
            avgBurnRate: totalHrs > 0 ? Number((totalVol / totalHrs).toFixed(2)) : 0,
            typeSummaries: Object.entries(typeGroupMap).map(([egy, val]) => ({
              egy,
              typeAlat: egy,
              totalVolume: Number(val.totalVolume.toFixed(1)),
              totalHours: Number(val.totalHours.toFixed(1)),
              recordCount: val.recordCount,
              burnRate: val.totalHours > 0 ? Number((val.totalVolume / val.totalHours).toFixed(2)) : 0
            })),
            unitSummaries: Object.values(unitGroupMap).map(u => ({
              idAlat: u.idAlat,
              egy: u.egy,
              typeAlat: u.typeAlat,
              totalVolume: Number(u.totalVolume.toFixed(1)),
              totalHours: Number(u.totalHours.toFixed(1)),
              recordCount: u.recordCount,
              burnRate: u.totalHours > 0 ? Number((u.totalVolume / u.totalHours).toFixed(2)) : 0
            }))
          };

          saveMonthlyReportToFirestore(monthlyReportPayload).catch(e => console.warn("Firestore autosave note:", e));
        } catch (syncErr) {
          console.warn("Sinkronisasi Firestore bulanan note:", syncErr);
        }
        
        const hasPlansMsg = Object.keys(plansExtracted).length > 0 
          ? ` dan ${Object.keys(plansExtracted).length} pembanding target plan dari sheet "List & FC"` 
          : "";
        
        setFileFeedback({
          type: "success",
          message: `Berhasil mengimpor & menganalisis ${parsed.length} baris data bahan bakar dari sheet "${logsSheetName}"${hasPlansMsg} dan tersimpan ke Firebase (fuel-wbs)!`
        });
      } catch (err: any) {
        setFileFeedback({
          type: "error",
          message: `Gagal membaca Excel: ${err.message || "Harap sesuaikan dengan susunan kolom template."}`
        });
      } finally {
        setIsProcessingFile(false);
        setSelectedFile(null);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelected(file);
    }
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      handleFileSelected(file);
    }
  };

  // Export Dashboard to PDF Function via html2canvas & jsPDF
  const exportToPdf = async () => {
    setIsExportingPdf(true);
    setFileFeedback({ type: null, message: "" });
    try {
      const element = document.getElementById("dashboard-to-export");
      if (!element) {
        throw new Error("Elemen analisis tidak ditemukan di draf halaman.");
      }
      
      const canvas = await html2canvas(element, {
        scale: 2, // super crisp presentation resolution
        useCORS: true,
        logging: false,
        backgroundColor: "#F8F9FA",
        onclone: (clonedDoc) => {
          // Native oklch color converter helper using canvas
          const canvasConvert = clonedDoc.createElement("canvas");
          canvasConvert.width = 1;
          canvasConvert.height = 1;
          const ctxConvert = canvasConvert.getContext("2d");

          const convertColor = (colorStr: string): string => {
            if (!colorStr || !colorStr.includes("oklch") || !ctxConvert) return colorStr;
            ctxConvert.fillStyle = colorStr;
            return ctxConvert.fillStyle;
          };

          const allElements = clonedDoc.getElementsByTagName("*");
          for (let i = 0; i < allElements.length; i++) {
            const el = allElements[i] as HTMLElement;
            const computed = window.getComputedStyle(el);
            
            const bg = computed.backgroundColor;
            const color = computed.color;
            const borderTopColor = computed.borderTopColor;
            const borderBottomColor = computed.borderBottomColor;
            const borderLeftColor = computed.borderLeftColor;
            const borderRightColor = computed.borderRightColor;
            const fill = computed.fill;
            const stroke = computed.stroke;

            if (bg && bg.includes("oklch")) {
              el.style.backgroundColor = convertColor(bg);
            }
            if (color && color.includes("oklch")) {
              el.style.color = convertColor(color);
            }
            if (borderTopColor && borderTopColor.includes("oklch")) {
              el.style.borderTopColor = convertColor(borderTopColor);
            }
            if (borderBottomColor && borderBottomColor.includes("oklch")) {
              el.style.borderBottomColor = convertColor(borderBottomColor);
            }
            if (borderLeftColor && borderLeftColor.includes("oklch")) {
              el.style.borderLeftColor = convertColor(borderLeftColor);
            }
            if (borderRightColor && borderRightColor.includes("oklch")) {
              el.style.borderRightColor = convertColor(borderRightColor);
            }
            if (fill && fill.includes("oklch")) {
              el.style.fill = convertColor(fill);
            }
            if (stroke && stroke.includes("oklch")) {
              el.style.stroke = convertColor(stroke);
            }
          }
        }
      });
      
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      
      const imgWidth = 210; // A4 layout width standard (mm)
      const pageHeight = 297; // A4 layout height standard (mm)
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;
      
      pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      pdf.save(`DASHBOARD_FUEL_ANALYSIS_PT_WBS_${new Date().toISOString().split('T')[0]}.pdf`);
      setFileFeedback({
        type: "success",
        message: "File PDF Analisis Pembakaran Diesel berhasil digenerasikan!"
      });
    } catch (err: any) {
      console.error(err);
      setFileFeedback({
        type: "error",
        message: `Gagal memproses file PDF: ${err.message || err}`
      });
    } finally {
      setIsExportingPdf(false);
    }
  };

  const triggerFileDialog = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
      fileInputRef.current.click();
    }
  };

  // Helpers to count global anomalies within filtered dataset
  const anomalousRecords = useMemo(() => {
    return filteredRecords.filter(r => r.isAnomaly);
  }, [filteredRecords]);

  const globalAnomaliesCount = useMemo(() => {
    return anomalousRecords.length;
  }, [anomalousRecords]);

  const totalGlobalAnomaliesCount = useMemo(() => {
    return records.filter(r => r.isAnomaly).length;
  }, [records]);

  const isAnomaliesFiltered = useMemo(() => {
    return selectedEgyFilter !== "SEMUA" || selectedStorageFilter !== "SEMUA";
  }, [selectedEgyFilter, selectedStorageFilter]);

  const handleClearFilters = () => {
    setSelectedEgyFilter("SEMUA");
    setSelectedStorageFilter("SEMUA");
    if (records.length > 0) {
      const validDates = records.map(p => p.tanggal).filter(t => t);
      if (validDates.length > 0) {
        const sorted = [...validDates].sort();
        setStartDate(sorted[0]);
        setEndDate(sorted[sorted.length - 1]);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex flex-col font-sans transition-colors duration-300">
      
      {/* Top Header - Professional Polish Theme */}
      <header className="bg-[#1E293B] border-b border-[#334155] shrink-0 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-18 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-inner overflow-hidden border border-[#334155] p-1 shrink-0">
              <img 
                src="https://res.cloudinary.com/dgjnlxf69/image/upload/v1787534678/Logo_Fuel_Monitor_air6wr.png" 
                alt="Logo Fuel Monitor PT. WBS" 
                className="w-8 h-8 object-contain" 
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h1 className="text-white font-extrabold tracking-tight text-md sm:text-lg flex items-center gap-2">
                DASHBOARD FUEL ANALYSIS
              </h1>
              <p className="text-[10px] text-[#94A3B8] font-bold tracking-widest uppercase">PT. WAHANA BARA SENTOSA</p>
            </div>
          </div>

          {/* Quick PDF Trigger in Header */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={exportToPdf}
              disabled={isExportingPdf || records.length === 0}
              className="flex items-center gap-2 text-xs bg-[#4682B4] hover:bg-[#36648B] disabled:opacity-50 font-bold text-white px-3 sm:px-4 py-2 rounded-lg shadow-sm transition active:scale-95 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isExportingPdf ? "Mencetak PDF..." : "Ekspor PDF"}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        
        {/* Navigation Tabs row below Header with Cloud Synch Badge */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex bg-slate-200/60 p-1 rounded-xl border border-slate-300/40 w-full sm:w-auto shadow-sm">
            <button
              onClick={() => {
                setActiveTab("dashboard");
                setViewingAnomaliesPage(false);
              }}
              className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-xs font-black transition-all cursor-pointer ${
                activeTab === "dashboard"
                  ? "bg-[#1E293B] text-white shadow"
                  : "text-slate-600 hover:text-slate-800"
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>MONTHLY REVIEW</span>
            </button>
            <button
              onClick={() => {
                setActiveTab("daily");
                setViewingAnomaliesPage(false);
              }}
              className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-xs font-black transition-all cursor-pointer ${
                activeTab === "daily"
                  ? "bg-[#1E293B] text-white shadow"
                  : "text-slate-600 hover:text-slate-800"
              }`}
            >
              <CalendarDays className="w-4 h-4" />
              <span>DAILY REVIEW</span>
            </button>
            <button
              onClick={() => {
                setActiveTab("yearly");
                setViewingAnomaliesPage(false);
              }}
              className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-xs font-black transition-all cursor-pointer ${
                activeTab === "yearly"
                  ? "bg-[#1E293B] text-white shadow"
                  : "text-slate-600 hover:text-slate-800"
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>YEARLY REVIEW</span>
            </button>
            <button
              onClick={() => {
                setActiveTab("plan");
                setViewingAnomaliesPage(false);
              }}
              className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-xs font-black transition-all cursor-pointer ${
                activeTab === "plan"
                  ? "bg-[#1E293B] text-white shadow"
                  : "text-slate-600 hover:text-slate-800"
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>INPUT PLAN FUEL BURN</span>
            </button>
          </div>

          {/* Cloud Synch Status Indicator (Green when connected, Red when off) */}
          <div className="flex items-center gap-2">
            {firestoreSyncStatus.isSynced ? (
              <div 
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-50 border border-emerald-200 shadow-xs text-xs font-bold text-emerald-800 transition"
                title={`Cloud Synch: Terkoneksi Realtime ke Firestore (${records.length} baris data)`}
              >
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <Cloud className="w-4 h-4 text-emerald-600 animate-pulse" />
                <span className="tracking-wide">Cloud Synch</span>
              </div>
            ) : (
              <div 
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-rose-50 border border-rose-200 shadow-xs text-xs font-bold text-rose-800 transition"
                title="Cloud Synch: Offline / Mode Penyimpanan Lokal"
              >
                <span className="inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
                <CloudOff className="w-4 h-4 text-rose-600" />
                <span className="tracking-wide">Cloud Synch</span>
              </div>
            )}
          </div>
        </div>

        {activeTab === "daily" ? (
          <DailyReviewView
            records={records}
            initialStartDate={startDate}
            initialEndDate={endDate}
            initialEgy={selectedEgyFilter}
            egyPlans={egyPlans}
            unitPlans={unitRegistry}
          />
        ) : activeTab === "plan" ? (
          <PlanFuelBurnPage
            egyPlans={egyPlans}
            unitRegistry={unitRegistry}
            onSaveEgyPlans={handleSaveEgyPlans}
            onSaveUnitRegistry={handleSaveUnitRegistry}
            records={records}
            onBackToDashboard={() => setActiveTab("dashboard")}
          />
        ) : activeTab === "yearly" ? (
          <YearlyReview 
            onBackToDashboard={() => setActiveTab("dashboard")} 
            egyPlans={egyPlans} 
            unitPlans={plans}
            records={records}
            onOpenPlanManager={() => setActiveTab("plan")} 
            onSyncRecords={(newRecs, uploadedMonthName) => {
              setRecords(newRecs);
              saveLocalData("fuel_records", newRecs);
              if (uploadedMonthName) {
                const monthMap: Record<string, string> = {
                  "Januari": "2026-01", "Februari": "2026-02", "Maret": "2026-03",
                  "April": "2026-04", "Mei": "2026-05", "Juni": "2026-06",
                  "Juli": "2026-07", "Agustus": "2026-08", "September": "2026-09",
                  "Oktober": "2026-10", "November": "2026-11", "Desember": "2026-12"
                };
                const ym = monthMap[uploadedMonthName] || (uploadedMonthName.startsWith("2026-") ? uploadedMonthName : undefined);
                if (ym) {
                  selectMonth(ym);
                }
              }
            }}
            onSelectMonthForDashboard={(mName) => {
              const monthMap: Record<string, string> = {
                "Januari": "2026-01", "Februari": "2026-02", "Maret": "2026-03",
                "April": "2026-04", "Mei": "2026-05", "Juni": "2026-06",
                "Juli": "2026-07", "Agustus": "2026-08", "September": "2026-09",
                "Oktober": "2026-10", "November": "2026-11", "Desember": "2026-12"
              };
              const ym = monthMap[mName] || `2026-${mName}`;
              selectMonth(ym);
              setActiveTab("dashboard");
            }}
          />
        ) : viewingAnomaliesPage ? (
          <AnomalyDetailsView
            anomalousRecords={anomalousRecords}
            allRecordsCount={filteredRecords.length}
            onBack={() => setViewingAnomaliesPage(false)}
            startDate={startDate}
            endDate={endDate}
            selectedEgy={selectedEgyFilter}
            selectedStorage={selectedStorageFilter}
            isFiltered={isAnomaliesFiltered}
            onClearFilters={handleClearFilters}
            totalGlobalAnomaliesCount={totalGlobalAnomaliesCount}
          />
        ) : (
          <>
            {/* Step-by-Step File Preview and Manual Analysis Trigger */}
            {selectedFile ? (
              <div className="bg-white rounded-xl border-2 border-amber-400 p-5 shadow-sm font-sans relative overflow-hidden animate-fade-in mb-4">
                <div className="absolute top-0 left-0 bottom-0 w-1.5 bg-amber-500"></div>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 pl-1.5">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
                      <FileSpreadsheet className="w-8 h-8" />
                    </div>
                    <div>
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-amber-600">File Report Terpilih, Siap Dianalisa</h4>
                      <h3 className="text-sm font-extrabold text-slate-800 mt-1 flex items-center flex-wrap gap-2">
                        {selectedFile.name}
                        <span className="text-xs font-medium text-slate-400">({(selectedFile.size / 1024).toFixed(1)} KB)</span>
                      </h3>
                      
                      {/* Sheet Selection Selector for Excel workbooks */}
                      {fileSheets.length > 0 ? (
                        <div className="mt-3.5 flex flex-col sm:flex-row sm:items-center gap-2.5">
                          <label className="text-xs text-slate-600 font-bold">Pilih Sheet Laporan Pengisian Fuel:</label>
                          <div className="relative inline-block">
                            <select
                              value={selectedLogSheet}
                              onChange={(e) => setSelectedLogSheet(e.target.value)}
                              className="text-xs border border-slate-300 rounded px-3 text-slate-700 bg-slate-50 font-bold py-1.5 focus:border-[#4682B4] focus:outline-none cursor-pointer pr-8 appearance-none shadow-sm"
                            >
                              {fileSheets.map((s) => (
                                <option key={s} value={s}>
                                  {s === "List & FC" ? `${s} (Target Plans)` : s}
                                </option>
                              ))}
                            </select>
                            <ChevronDown className="w-4 h-4 text-slate-600 absolute right-2 top-2 pointer-events-none" />
                          </div>
                          
                          {hasPlanSheetPresent && (
                            <span className="inline-flex items-center gap-1.5 text-[10px] text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full font-extrabold border border-emerald-200 mt-1 sm:mt-0">
                              <Sparkles className="w-3 h-3" />
                              <span>Mendeteksi Sheet Pembanding "List & FC"</span>
                            </span>
                          )}
                        </div>
                      ) : (
                        <p className="text-[10px] text-slate-500 mt-1.5 font-medium">Laporan berformat CSV akan diproses baris per baris secara otomatis.</p>
                      )}
                    </div>
                  </div>

                  {/* ACTION EXECUTE BUTTONS */}
                  <div className="flex items-center gap-2 self-stretch md:self-auto justify-end border-t border-slate-100 md:border-t-0 pt-3 md:pt-0 mt-3 md:mt-0">
                    <button
                      onClick={() => setSelectedFile(null)}
                      disabled={isProcessingFile}
                      className="text-xs font-bold text-slate-500 hover:text-slate-700 hover:bg-slate-50 border border-slate-200 px-3.5 py-2.5 rounded-lg transition active:scale-95 cursor-pointer bg-white"
                    >
                      Batal
                    </button>
                    <button
                      onClick={() => processUploadedFile(selectedFile, selectedLogSheet)}
                      disabled={isProcessingFile}
                      className="text-xs bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 disabled:opacity-50 text-slate-950 px-4.5 py-2.5 rounded-lg font-black tracking-tight transition shadow-sm cursor-pointer active:scale-95 flex items-center justify-center gap-2 relative group overflow-hidden"
                    >
                      <Sparkles className="w-4 h-4 text-slate-950 fill-slate-950" />
                      <span>{isProcessingFile ? "Sedang Menganalisis..." : "Mulai Analisa Data Excel"}</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* Real-time File Drop Zone / Import Selector Bar - Focused on Excel */
              <div 
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleFileDrop}
                className={`border-2 border-dashed rounded-2xl p-5 mb-4 transition-all text-center sm:text-left flex flex-col md:flex-row items-center justify-between gap-4 ${
                  isDragging 
                    ? "border-[#4682B4] bg-[#4682B4]/5 shadow" 
                    : "border-slate-200 hover:border-[#4682B4]/60 bg-white shadow-xs"
                }`}
              >
                <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
                  <div className="p-3.5 bg-emerald-50 text-emerald-600 rounded-2xl self-center shrink-0 border border-emerald-100">
                    <FileSpreadsheet className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-800 tracking-tight flex items-center gap-2 justify-center sm:justify-start">
                      <span>Upload File Report Fuel Excel</span>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                        .xlsx / .xls
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 tracking-normal max-w-xl">
                      Seret file Excel report fuel ke sini atau klik tombol untuk memilih berkas Excel langsung dari perangkat Anda.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center justify-center gap-2 shrink-0 font-sans">
                  <button 
                    onClick={triggerFileDialog}
                    disabled={isProcessingFile}
                    className="text-xs bg-[#4682B4] hover:bg-[#36648B] disabled:opacity-50 text-white px-5 py-3 rounded-xl font-bold transition shadow-sm cursor-pointer active:scale-95 flex items-center gap-2"
                  >
                    <Upload className="w-4 h-4 text-sky-100" />
                    <span>Upload File Excel</span>
                  </button>
                  <input 
                    ref={fileInputRef}
                    type="file" 
                    accept=".xlsx,.xls,.csv,.txt" 
                    className="hidden" 
                    onChange={handleFileChange}
                  />
                </div>
              </div>
            )}

        {/* Dynamic Process Indicator and File Feedback Banner */}
        {fileFeedback.type && (
          <div className="space-y-3 mb-4">
            <div className={`p-4 rounded-xl border flex items-start gap-3 transition-all animate-fade-in ${
              fileFeedback.type === "success" 
                ? "bg-[#E6F4EA] border-[#B3E1C1] text-[#137333]" 
                : "bg-rose-50 border-rose-200 text-rose-800"
            }`}>
              {fileFeedback.type === "success" ? (
                <Sparkles className="w-5 h-5 shrink-0 text-[#137333] mt-0.5" />
              ) : (
                <AlertTriangle className="w-5 h-5 shrink-0 text-rose-600 mt-0.5" />
              )}
              <div className="text-xs font-medium font-sans flex-1">
                <strong className="block font-bold mb-0.5 text-rose-900">
                  {fileFeedback.type === "success" ? "Proses Impor Sukses!" : "Kesalahan Pembacaan Berkas Excel!"}
                </strong>
                <span>{fileFeedback.message}</span>
              </div>
            </div>
          </div>
        )}

        {/* Interactive Filters Panel */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 sm:p-5 flex flex-wrap items-center gap-4 sm:gap-6 font-sans">
          
          {/* Quick Month Dropdown from Uploaded Data */}
          {availableMonths.length > 0 && (
            <div className="flex flex-col">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                <Calendar className="w-3 h-3 text-[#4682B4]" />
                <span>PILIH BULAN</span>
              </label>
              <select
                value={
                  availableMonths.find(m => m.startDate === startDate && m.endDate === endDate)?.yearMonth ||
                  availableMonths.find(m => startDate && startDate.startsWith(m.yearMonth))?.yearMonth || ""
                }
                onChange={(e) => {
                  if (e.target.value) {
                    selectMonth(e.target.value);
                  }
                }}
                className="text-xs border border-slate-300 rounded px-2.5 py-1.5 bg-slate-50 text-slate-800 font-semibold mt-1 focus:border-[#4682B4] focus:outline-none cursor-pointer"
              >
                <option value="">-- Pilih Periode Bulan --</option>
                {availableMonths.map(m => (
                  <option key={m.yearMonth} value={m.yearMonth}>
                    {m.label} ({m.recordCount} log)
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Date Range Picker */}
          <div className="flex flex-col">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
              <Calendar className="w-3 h-3 text-[#4682B4]" />
              <span>RENTANG TANGGAL</span>
            </label>
            <div className="flex items-center gap-2 mt-1">
              <input
                type="date"
                className="text-xs border border-slate-300 rounded px-2.5 py-1.5 bg-slate-50 text-slate-800 transition focus:border-[#4682B4] focus:outline-none font-medium"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
              <span className="text-slate-400 text-xs font-bold">-</span>
              <input
                type="date"
                className="text-xs border border-slate-300 rounded px-2.5 py-1.5 bg-slate-50 text-slate-800 transition focus:border-[#4682B4] focus:outline-none font-medium"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>

          {/* Egy Alat Filter - Placed directly next to Rentang Tanggal */}
          <div className="flex flex-col">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
              <Filter className="w-3 h-3 text-[#4682B4]" />
              <span>EGY ALAT (EQUIPMENT)</span>
            </label>
            <select
              value={selectedEgyFilter}
              onChange={(e) => setSelectedEgyFilter(e.target.value)}
              className="text-xs border border-slate-300 rounded px-2.5 py-1.5 bg-slate-50 mt-1 select-none w-full sm:w-60 focus:border-[#4682B4] focus:outline-none font-medium text-slate-700 cursor-pointer"
            >
              <option value="SEMUA">Semua Egy Alat</option>
              {uniqueEgys.map(egy => (
                <option key={egy} value={egy}>{egy}</option>
              ))}
            </select>
          </div>

          {/* Nomor Unit Selector Checklist - Placed directly next to Egy Alat */}
          <UnitSelectorDropdown
            units={availableUnitsForEgy}
            selectedUnitIds={selectedUnitFilter}
            onChangeSelectedUnitIds={setSelectedUnitFilter}
            selectedEgy={selectedEgyFilter}
          />

        </div>

        {/* PRINT TARGET CONTAINER - Everything inside is grabbed beautifully for PDF report rendering */}
        <div id="dashboard-to-export" className="space-y-6 bg-slate-50 p-4 sm:p-6 rounded-2xl border border-slate-200">
          
          {/* Visual Feedback on Chosen Reference Date - Polished Indicator */}
          {referenceDate && (
            <div className="bg-[#1E293B] text-slate-350 px-4 py-3 rounded-xl border border-slate-700/60 text-xs flex flex-col sm:flex-row justify-between items-start sm:items-center shadow-sm gap-2 shrink-0 select-none">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>
                  Tanggal Acuan Analisa Fuel: <strong className="text-white font-mono">{referenceDate}</strong>
                </span>
              </div>
              <div className="text-[10px] text-slate-400 tracking-wide uppercase font-mono bg-slate-800 py-0.5 px-2 rounded">
                Status: Berjalan (Realtime)
              </div>
            </div>
          )}

          {/* Metric KPI Card Grid View */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            <MetricCard
              title="Rerata Fuel Burn Harian (Daily)"
              value={metrics.daily.average}
              subValue={metrics.daily.count > 0 ? "Berdasarkan rincian harian log pengisian" : "Tidak ada transaksi pada tanggal acuan"}
              totalFuel={metrics.daily.fuel}
              totalHours={metrics.daily.hours}
              recordCount={metrics.daily.count}
              anomalyCount={metrics.daily.anomalies}
              periodText={referenceDate || "Tidak Terdeteksi"}
              themeColor="blue"
              helpText="Rata-rata pemakaian bahan bakar per jam di tanggal acuan (Daily). Dihitung dari seluruh pengisian non-anomali di hari bersangkutan."
            />

            <MetricCard
              title="Rerata Month to Date (MTD)"
              value={metrics.mtd.average}
              subValue={`Bulan ${referenceDate ? new Date(referenceDate).toLocaleString("id-ID", {month: "long", year:"numeric"}) : "pilihan"}`}
              totalFuel={metrics.mtd.fuel}
              totalHours={metrics.mtd.hours}
              recordCount={metrics.mtd.count}
              anomalyCount={metrics.mtd.anomalies}
              periodText={referenceDate ? `01 s/d ${referenceDate.substring(8, 10)} ${new Date(referenceDate).toLocaleString("id-ID", {month: "short", year: "numeric"})}` : "Tidak Terdeteksi"}
              themeColor="emerald"
              helpText="Rata-rata pemakaian bahan bakar per jam berjalan sejak tanggal 1 sampai tanggal acuan di bulan yang sama (MTD)."
            />

            <MetricCard
              title="Rerata Year to Date (YTD)"
              value={metrics.ytd.average}
              subValue={`Tahun ${referenceDate ? referenceDate.substring(0, 4) : "pilihan"}`}
              totalFuel={metrics.ytd.fuel}
              totalHours={metrics.ytd.hours}
              recordCount={metrics.ytd.count}
              anomalyCount={metrics.ytd.anomalies}
              periodText={referenceDate ? `01 Jan s/d ${referenceDate.substring(8, 10)} ${new Date(referenceDate).toLocaleString("id-ID", {month: "short", year: "numeric"})}` : "Tidak Terdeteksi"}
              themeColor="amber"
              helpText="Rata-rata pemakaian bahan bakar per jam berjalan sejak awal tahun (1 Januari) sampai tanggal acuan di tahun yang sama (YTD)."
            />

          </div>

          {/* Unit Over Plan Monitor Section */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-100 pb-4 mb-4 gap-2">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
                  Monitoring Deviasi Efisiensi Unit (Aktual vs Target Plan)
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Menganalisis unit alat berat yang melampaui batas Fuel Burn plan (Over Plan) yang diambil dari sheet <strong className="font-mono">List & FC</strong>.
                </p>
              </div>
              <div className="bg-slate-100 text-slate-705 text-[10.5px] px-3 py-1 rounded-full font-semibold">
                Terdeteksi: <strong className="text-rose-600">{overPlanUnits.length}</strong> / {unitComparisons.length} Unit Over Plan
              </div>
            </div>

            {overPlanUnits.length === 0 ? (
              <div className="text-center py-8 bg-slate-50 rounded-lg text-slate-500 text-xs border border-dashed border-slate-200">
                <p className="font-bold text-emerald-600 font-sans text-xs">💪 SEMUA UNIT BERJALAN EFISIEN</p>
                <p className="mt-1 text-slate-400">Tidak ada unit alat berat yang melampaui plan Fuel Burn yang terdaftar pada target sheet.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Visual Stats Bar summarizing the waste */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-rose-50 border border-rose-100 p-3.5 rounded-xl">
                    <span className="text-[10px] text-rose-500 uppercase tracking-widest font-extrabold block">Unit Terboros (Max Deviation)</span>
                    <div className="text-lg font-black text-rose-700 flex items-center gap-1.5 mt-1">
                      <span>{overPlanUnits[0].idAlat}</span>
                      <span className="text-xs font-bold text-rose-600">({cleanEgyName(overPlanUnits[0].egy || deriveEgy(overPlanUnits[0].idAlat, overPlanUnits[0].typeAlat))})</span>
                    </div>
                    <span className="text-xs text-rose-650 mt-1 block">
                      Deviasi: <strong className="font-bold">+{overPlanUnits[0].deviation.toFixed(2)}</strong> L/Jam (<span className="font-extrabold text-slate-800">+{overPlanUnits[0].deviationPct.toFixed(1)}%</span> over plan)
                    </span>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
                    <span className="text-[10px] text-slate-550 uppercase tracking-widest font-extrabold block">Rerata Kelebihan Konsumsi</span>
                    <span className="text-lg font-black text-slate-800 mt-1 block">
                      +{(overPlanUnits.reduce((acc, u) => acc + u.deviation, 0) / overPlanUnits.length).toFixed(2)} <span className="text-xs font-semibold text-slate-500">L/Jam per unit</span>
                    </span>
                    <span className="text-xs text-slate-500 mt-1 block">
                      Rata-rata deviasi kumulatif dari seluruh unit yang boros melampaui plan.
                    </span>
                  </div>

                  <div className="bg-amber-50 border border-amber-100 p-3.5 rounded-xl">
                    <span className="text-[10px] text-amber-600 uppercase tracking-widest font-extrabold block">Estimasi Kelebihan Konsumsi Fuel</span>
                    <span className="text-lg font-black text-amber-800 mt-1 block">
                      {overPlanUnits.reduce((acc, u) => acc + (u.deviation * u.totalHours), 0).toLocaleString("id-ID", { maximumFractionDigits: 1 })} <span className="text-xs font-semibold text-amber-650">Liter</span>
                    </span>
                    <span className="text-xs text-amber-700 mt-1 block">
                      Akumulasi potensi inefisiensi liter bahan bakar selama jam operasional aktif.
                    </span>
                  </div>
                </div>

                {/* Over plan detailed list view */}
                <div className="overflow-x-auto border border-slate-100 rounded-lg">
                  <table className="w-full text-left text-xs text-slate-650 font-sans">
                    <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-100">
                      <tr>
                        <th className="py-2.5 px-3">Nomor Unit / ID Alat</th>
                        <th className="py-2.5 px-3">Egy Alat</th>
                        <th className="py-2.5 px-3 text-right">Target Plan</th>
                        <th className="py-2.5 px-3 text-right">Konsumsi Aktual</th>
                        <th className="py-2.5 px-3 text-right">Deviasi (L/Jam)</th>
                        <th className="py-2.5 px-3 text-right">Kelebihan (%)</th>
                        <th className="py-2.5 px-3 text-right">Total Jam Kerja</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {overPlanUnits.map((u, i) => (
                        <tr key={i} className="hover:bg-rose-50/20 transition-all">
                          <td className="py-3 px-3 font-bold text-slate-800 font-sans">
                            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 border border-slate-200 font-mono font-bold">
                              {u.idAlat}
                            </span>
                          </td>
                          <td className="py-3 px-3 font-semibold text-slate-700">
                            <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded text-[11px] font-bold border border-slate-200">
                              {cleanEgyName(u.egy || deriveEgy(u.idAlat, u.typeAlat))}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right text-slate-500 font-semibold font-mono">{u.plan.toFixed(1)} L/Jam</td>
                          <td className="py-3 px-3 text-right text-rose-700 font-bold font-mono">{u.actual.toFixed(2)} L/Jam</td>
                          <td className="py-3 px-3 text-right text-rose-600 font-black font-mono">+{u.deviation.toFixed(2)}</td>
                          <td className="py-3 px-3 text-right font-black font-mono">
                            <span className="bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full text-[10px]">
                              +{u.deviationPct.toFixed(1)}%
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right text-slate-400 font-mono">{u.totalHours.toLocaleString("id-ID", { maximumFractionDigits: 1 })} Jam</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* PENILAIAN PLAN VS ACTUAL FUEL BURN BERDASARKAN JENIS EGY */}
          <PlanVsActualAssessment
            records={filteredRecords}
            egyPlans={egyPlans}
            unitPlans={plans}
            onOpenPlanManager={() => setActiveTab("plan")}
            selectedEgyFilter={selectedEgyFilter}
          />

          {/* Central Pareto Layout */}
          <ParetoChart 
            records={filteredRecords} 
            selectedType="SEMUA" 
            plans={plans} 
            egyPlans={egyPlans} 
          />

          {/* Quick Metrics of anomalies across full log */}
          {globalAnomaliesCount > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex gap-3 items-start sm:items-center">
                <div className="bg-amber-100 p-2 rounded-full text-amber-700 shrink-0">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-amber-900 leading-none">Mendeteksi {globalAnomaliesCount} Anomali Log Bahan Bakar</h4>
                  <p className="text-xs text-amber-700 mt-1 leading-relaxed">
                    Log dengan selisih HM bernilai 0, negatif, atau pembakaran tidak wajar secara otomatis disisihkan dari perhitungan rata-rata agar data efisiensi tidak bias.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setViewingAnomaliesPage(true)}
                className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs py-2 px-4 rounded-lg shadow-sm transition active:scale-95 flex items-center gap-1.5 shrink-0 select-none cursor-pointer"
              >
                <span>Lihat Halaman Anomali</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>
        </>
      )}
      </main>

      {/* MODAL PENGELOLA TARGET PLAN FUEL BURN PER JENIS EGY */}
      <EgyPlanManagerModal
        isOpen={isEgyPlanModalOpen}
        onClose={() => setIsEgyPlanModalOpen(false)}
        currentPlans={egyPlans}
        onSavePlans={handleSaveEgyPlans}
        availableEgysInDataset={availableEgys}
      />

      {/* Corporate Styled Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 py-6 px-6 text-center text-xs tracking-wide shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 PT. WAHANA BARA SENTOSA - Fuel Operations Internal Analyst Engine.</p>
          <div className="text-[10px] text-slate-500 font-mono">
            VITE • REACT • TAILWIND CSS
          </div>
        </div>
      </footer>

    </div>
  );
}
